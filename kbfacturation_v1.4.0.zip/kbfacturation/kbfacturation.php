<?php
/**
 * Kelbongoo - Facturation PDV -> PrestaShop
 *
 * Reçoit (API signée HMAC) le résultat de la facturation PDV d'une commande web
 * (facture + avoirs éventuels) et met la commande PrestaShop au montant réel :
 * quantités livrées, prix remisés, lignes en rupture retirées, totaux, note,
 * statut « Facturée PDV ». Capture PayZen au montant net (désactivée par défaut).
 *
 * PDV reste la source de vérité : ce module ne calcule rien, il applique et vérifie.
 *
 * @version 1.4.0 - 27/10/2026 (action « facturer » : facture + avoir PDV via G5, site, PayZen — déclenchée par l'appli)
 * @version 1.3.1 - 26/10/2026 (auto-réparation : colonne detail + hooks si la mise à niveau n'est pas passée)
 * @version 1.3.0 - 26/10/2026 (récap ligne à ligne : produits retirés barrés, côté admin et client)
 * @version 1.2.0 - 26/10/2026 (journal envoyé au suivi Master de l'appli Kelbongoo)
 * @version 1.1.0 - 26/10/2026 (lecture directe des factures/avoirs PDV via l'API G5)
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/KbFacturationService.php';
require_once __DIR__ . '/classes/KbFacturationPayzen.php';
require_once __DIR__ . '/classes/KbFacturationG5.php';
require_once __DIR__ . '/classes/KbFacturationSuivi.php';
require_once __DIR__ . '/classes/KbFacturationComplet.php';

class Kbfacturation extends Module
{
    const CFG_SECRET = 'KBFACT_SECRET';
    const CFG_STATE_FACTURE = 'KBFACT_STATE_FACTURE';
    const CFG_CAPTURE_ON = 'KBFACT_CAPTURE_ON';
    const CFG_PZ_SHOP = 'KBFACT_PZ_SHOP_ID';
    const CFG_PZ_KEY = 'KBFACT_PZ_REST_PASSWORD';
    const CFG_PZ_URL = 'KBFACT_PZ_ENDPOINT';
    const CFG_G5_URL = 'KBFACT_G5_URL';
    const G5_DEFAUT = 'http://172.21.3.94:8080/axis2/services/';
    const CFG_LOG_URL = 'KBFACT_LOG_URL';
    const CFG_BCC_PREFIX = 'KBFACT_BCC_PREFIX';
    const LOG_URL_DEFAUT = 'https://europe-west1-distribkbg.cloudfunctions.net/kbgFactuLog';

    public function __construct()
    {
        $this->name = 'kbfacturation';
        $this->tab = 'administration';
        $this->version = '1.4.0';
        $this->author = 'Kelbongoo';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => _PS_VERSION_];
        parent::__construct();
        $this->displayName = $this->l('Kelbongoo - Facturation PDV');
        $this->description = $this->l('Met les commandes web au montant réel facturé par PDV (facture + avoirs) et capture PayZen au bon montant.');
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->installState()
            && Configuration::updateValue(self::CFG_SECRET, bin2hex(random_bytes(32)))
            && Configuration::updateValue(self::CFG_CAPTURE_ON, 0)
            && Configuration::updateValue(self::CFG_PZ_URL, 'https://api.payzen.eu/api-payment/V4/')
            && Configuration::updateValue(self::CFG_G5_URL, self::G5_DEFAUT)
            && Configuration::updateValue(self::CFG_LOG_URL, self::LOG_URL_DEFAUT)
            && $this->registerHook('displayAdminOrderSide')
            && $this->registerHook('displayAdminOrderMainBottom')
            && $this->registerHook('displayOrderDetail');
    }

    public function uninstall()
    {
        // Les tables de suivi sont conservées volontairement (traçabilité comptable).
        foreach ([self::CFG_SECRET, self::CFG_CAPTURE_ON, self::CFG_PZ_SHOP, self::CFG_PZ_KEY, self::CFG_PZ_URL, self::CFG_G5_URL, self::CFG_LOG_URL] as $k) {
            Configuration::deleteByName($k);
        }
        return parent::uninstall();
    }

    private function installDb()
    {
        $p = _DB_PREFIX_;
        $e = _MYSQL_ENGINE_;
        $sql = [
            "CREATE TABLE IF NOT EXISTS `{$p}kbfact_order` (
                `id_order` INT UNSIGNED NOT NULL PRIMARY KEY,
                `pdv_commande` VARCHAR(32) NOT NULL,
                `pdv_facture` VARCHAR(32) NOT NULL,
                `pdv_avoirs` VARCHAR(255) NOT NULL DEFAULT '',
                `total_initial_ttc` DECIMAL(20,6) NOT NULL,
                `net_ttc` DECIMAL(20,6) NOT NULL,
                `captured` TINYINT(1) NOT NULL DEFAULT 0,
                `captured_amount` DECIMAL(20,6) NULL,
                `detail` MEDIUMTEXT NULL,
                `date_applied` DATETIME NOT NULL,
                `date_captured` DATETIME NULL
            ) ENGINE={$e} DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS `{$p}kbfact_log` (
                `id_log` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `id_order` INT UNSIGNED NULL,
                `action` VARCHAR(20) NOT NULL,
                `ok` TINYINT(1) NOT NULL,
                `message` TEXT NOT NULL,
                `payload` MEDIUMTEXT NULL,
                `date_add` DATETIME NOT NULL,
                KEY `id_order` (`id_order`)
            ) ENGINE={$e} DEFAULT CHARSET=utf8mb4",
        ];
        foreach ($sql as $q) {
            if (!Db::getInstance()->execute($q)) {
                return false;
            }
        }
        return true;
    }

    private function installState()
    {
        $existing = (int) Configuration::get(self::CFG_STATE_FACTURE);
        if ($existing && Validate::isLoadedObject(new OrderState($existing))) {
            return true;
        }
        $state = new OrderState();
        foreach (Language::getLanguages(false) as $lang) {
            $state->name[(int) $lang['id_lang']] = 'Facturée PDV - montant ajusté';
        }
        $state->color = '#7B2FBE';
        $state->module_name = $this->name;
        $state->send_email = false;
        $state->logable = false;
        $state->paid = false;
        $state->invoice = false;
        $state->shipped = false;
        $state->delivery = false;
        $state->hidden = false;
        $state->unremovable = true;
        if (!$state->add()) {
            return false;
        }
        return Configuration::updateValue(self::CFG_STATE_FACTURE, (int) $state->id);
    }

    /* ------------------------------------------------------------------ */
    /* Configuration                                                      */
    /* ------------------------------------------------------------------ */

    public function getContent()
    {
        $this->assurerSchema();
        $out = '';
        if (Tools::isSubmit('kbfact_save')) {
            Configuration::updateValue(self::CFG_CAPTURE_ON, (int) Tools::getValue(self::CFG_CAPTURE_ON));
            Configuration::updateValue(self::CFG_PZ_SHOP, trim((string) Tools::getValue(self::CFG_PZ_SHOP)));
            Configuration::updateValue(self::CFG_PZ_URL, trim((string) Tools::getValue(self::CFG_PZ_URL)));
            Configuration::updateValue(self::CFG_LOG_URL, trim((string) Tools::getValue(self::CFG_LOG_URL)));
            $pw = (string) Tools::getValue(self::CFG_PZ_KEY);
            if ($pw !== '') {
                Configuration::updateValue(self::CFG_PZ_KEY, trim($pw));
            }
            $out .= $this->displayConfirmation('Configuration enregistrée.');
        }
        if (Tools::isSubmit('kbfact_regen')) {
            Configuration::updateValue(self::CFG_SECRET, bin2hex(random_bytes(32)));
            $out .= $this->displayWarning('Nouveau secret généré : mettre à jour le script du serveur 98 ET le secret FACTU_LOG_SECRET de la Cloud Function kbgFactuLog.');
        }
        if (Tools::isSubmit('kbfact_suivi_test')) {
            [$ok, $info] = KbFacturationSuivi::envoyer([[
                'uid' => 'test-' . time(), 'source' => 'prestashop', 'date' => date('Y-m-d H:i:s'), 'id_order' => null,
                'reference' => '', 'action' => 'test', 'ok' => true, 'message' => 'Test de liaison depuis PrestaShop', 'resultat' => null,
                'pdv_commande' => '', 'pdv_facture' => '', 'pdv_avoirs' => [],
            ]], 8);
            $out .= $ok ? $this->displayConfirmation('Suivi app Kelbongoo : liaison OK.') : $this->displayError('Suivi app Kelbongoo : ' . Tools::safeOutput($info));
        }
        if (Tools::isSubmit('kbfact_suivi_histo')) {
            [$ok, $info] = KbFacturationSuivi::renvoyerHistorique(500);
            $out .= $ok ? $this->displayConfirmation('Historique renvoyé : ' . Tools::safeOutput($info)) : $this->displayError('Historique : ' . Tools::safeOutput($info));
        }

        // Application manuelle (secours / contrôle) : le module relit la facture + avoirs dans PDV
        $manuel = '';
        if (Tools::isSubmit('kbfact_manuel')) {
            $ref = strtoupper(trim((string) Tools::getValue('m_reference')));
            $fac = trim((string) Tools::getValue('m_facture'));
            $cmd = trim((string) Tools::getValue('m_commande'));
            $avs = array_values(array_filter(array_map('trim', explode(',', (string) Tools::getValue('m_avoirs')))));
            $dry = (bool) Tools::getValue('m_simulation');
            $p = ['reference' => $ref, 'pdv' => ['commande' => $cmd, 'facture' => $fac, 'avoirs' => $avs], 'dry_run' => $dry];
            $svc = new KbFacturationService($this);
            $idOrder = null;
            try {
                $idOrder = (int) $svc->loadOrder($p)->id;
                $etat = (new KbFacturationG5())->etatFinal($fac, $avs);
                $p['net_ttc'] = $etat['net_ttc'];
                $p['lignes'] = $etat['lignes'];
                $r = $svc->appliquer($p);
                $this->journalAdmin($idOrder, $dry ? 'manuel_sim' : 'manuel', true, json_encode($r, JSON_UNESCAPED_UNICODE), $p);
                $manuel = $this->displayConfirmation(($dry ? 'SIMULATION (rien écrit) — ' : 'APPLIQUÉ — ') . 'commande ' . Tools::safeOutput($ref)
                    . ' : ' . $svc->eur($r['total_initial_ttc'] ?? 0) . ' → ' . $svc->eur($r['net_ttc'] ?? 0) . '<br>'
                    . implode('<br>', array_map('Tools::safeOutput', (array) ($r['modifications'] ?? [$r['statut'] ?? '']))));
            } catch (Exception $e) {
                $this->journalAdmin($idOrder, $dry ? 'manuel_sim' : 'manuel', false, $e->getMessage(), $p);
                $manuel = $this->displayError(Tools::safeOutput($e->getMessage()));
            }
        }
        $out .= $manuel;

        $endpoint = $this->context->link->getModuleLink($this->name, 'api', [], true);
        $secret = (string) Configuration::get(self::CFG_SECRET);
        $logs = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_log` ORDER BY id_log DESC LIMIT 25'
        ) ?: [];
        $rows = '';
        foreach ($logs as $l) {
            $rows .= '<tr><td>' . (int) $l['id_log'] . '</td><td>' . pSQL($l['date_add']) . '</td><td>'
                . (int) $l['id_order'] . '</td><td>' . Tools::safeOutput($l['action']) . '</td><td>'
                . ($l['ok'] ? '<span style="color:#1a7f37;font-weight:700">OK</span>' : '<span style="color:#c00;font-weight:700">ERREUR</span>')
                . '</td><td style="max-width:600px;white-space:normal">' . Tools::safeOutput($l['message']) . '</td></tr>';
        }
        $capOn = (int) Configuration::get(self::CFG_CAPTURE_ON);
        $action = Tools::safeOutput($_SERVER['REQUEST_URI']);
        $shop = Tools::safeOutput((string) Configuration::get(self::CFG_PZ_SHOP));
        $url = Tools::safeOutput((string) Configuration::get(self::CFG_PZ_URL));
        $pwSet = Configuration::get(self::CFG_PZ_KEY) ? 'enregistré (laisser vide pour conserver)' : 'non renseigné';
        $g5 = Tools::safeOutput((string) Configuration::get(self::CFG_G5_URL));
        $logUrl = Tools::safeOutput((string) Configuration::get(self::CFG_LOG_URL));

        $out .= <<<HTML
<div class="panel"><h3>Liaison serveur PDV (98SERVEUR01)</h3>
<p><b>Adresse API :</b> <code>{$endpoint}</code></p>
<p><b>Secret HMAC</b> (à copier dans <code>kbg_facturation.ini</code> du serveur 98) :
<code id="kbsec" style="filter:blur(5px)" onclick="this.style.filter='none'">{$secret}</code> <small>(cliquer pour afficher)</small></p>
<form method="post" action="{$action}"><button class="btn btn-default" name="kbfact_regen" value="1"
 onclick="return confirm('Régénérer le secret ? Le script du serveur 98 devra être mis à jour.')">Régénérer le secret</button></form>
</div>
<div class="panel"><h3>Appliquer une facturation PDV (secours manuel)</h3>
<p>Le module relit lui-même la facture et les avoirs dans PDV (serveur G5 <code>{$g5}</code>) puis met la commande au montant réel. Toujours faire une simulation d'abord.</p>
<form method="post" action="{$action}" class="form-inline">
<input class="form-control" name="m_reference" placeholder="Réf. commande (ex. OQWHFGQIZ)" style="width:210px">
<input class="form-control" name="m_commande" placeholder="Commande PDV (98-98-33)" style="width:190px">
<input class="form-control" name="m_facture" placeholder="Facture PDV (98-98-2)" style="width:170px">
<input class="form-control" name="m_avoirs" placeholder="Avoir(s) PDV, séparés par ," style="width:220px">
<label style="margin:0 10px"><input type="checkbox" name="m_simulation" value="1" checked> Simulation</label>
<button class="btn btn-primary" name="kbfact_manuel" value="1">Lancer</button>
</form></div>
<div class="panel"><h3>Suivi dans l'appli Kelbongoo (Master › Facturation web)</h3>
<p>Chaque ligne du journal ci-dessous est aussi envoyée à l'appli (signée avec le secret ci-dessus). Un échec d'envoi ne bloque jamais la facturation.</p>
<form method="post" action="{$action}" class="form-inline">
<input class="form-control" name="KBFACT_LOG_URL" value="{$logUrl}" style="width:560px" placeholder="https://europe-west1-distribkbg.cloudfunctions.net/kbgFactuLog">
<input type="hidden" name="KBFACT_CAPTURE_ON" value="{$capOn}"><input type="hidden" name="KBFACT_PZ_SHOP_ID" value="{$shop}"><input type="hidden" name="KBFACT_PZ_ENDPOINT" value="{$url}">
<button class="btn btn-primary" name="kbfact_save" value="1">Enregistrer</button>
<button class="btn btn-default" name="kbfact_suivi_test" value="1">Tester la liaison</button>
<button class="btn btn-default" name="kbfact_suivi_histo" value="1">Renvoyer l'historique</button>
</form></div>
<div class="panel"><h3>PayZen — capture au montant net</h3>
<form method="post" action="{$action}" class="form-horizontal">
<div class="form-group"><label class="control-label col-lg-3">Capture automatique</label><div class="col-lg-9">
<select name="KBFACT_CAPTURE_ON" class="form-control" style="max-width:260px">
<option value="0" {$this->sel($capOn,0)}>Désactivée (aucun débit)</option>
<option value="1" {$this->sel($capOn,1)}>Activée</option></select></div></div>
<div class="form-group"><label class="control-label col-lg-3">Identifiant boutique PayZen</label><div class="col-lg-9">
<input type="text" name="KBFACT_PZ_SHOP_ID" value="{$shop}" class="form-control" style="max-width:260px"></div></div>
<div class="form-group"><label class="control-label col-lg-3">Mot de passe API REST PayZen</label><div class="col-lg-9">
<input type="password" name="KBFACT_PZ_REST_PASSWORD" value="" autocomplete="new-password" class="form-control" style="max-width:420px">
<p class="help-block">{$pwSet} — Back-office PayZen › Paramétrage › Boutique › Clés d'API REST (prendre la clé de PRODUCTION ou de TEST selon le mode).</p></div></div>
<div class="form-group"><label class="control-label col-lg-3">Serveur API PayZen</label><div class="col-lg-9">
<input type="text" name="KBFACT_PZ_ENDPOINT" value="{$url}" class="form-control" style="max-width:420px"></div></div>
<input type="hidden" name="KBFACT_LOG_URL" value="{$logUrl}">
<div class="panel-footer"><button type="submit" name="kbfact_save" value="1" class="btn btn-primary pull-right">Enregistrer</button></div>
</form></div>
<div class="panel"><h3>Journal (25 derniers appels)</h3>
<table class="table"><thead><tr><th>#</th><th>Date</th><th>Commande</th><th>Action</th><th>Résultat</th><th>Détail</th></tr></thead>
<tbody>{$rows}</tbody></table></div>
HTML;
        return $out;
    }

    private function journalAdmin($idOrder, $action, $ok, $msg, $ctx = null)
    {
        $emp = isset($this->context->employee->email) ? ' [' . $this->context->employee->email . ']' : '';
        Db::getInstance()->insert('kbfact_log', [
            'id_order' => $idOrder ? (int) $idOrder : null,
            'action' => pSQL($action),
            'ok' => $ok ? 1 : 0,
            'message' => pSQL(Tools::substr($msg . $emp, 0, 60000)),
            'payload' => $ctx === null ? null : pSQL(json_encode($ctx, JSON_UNESCAPED_UNICODE)),
            'date_add' => date('Y-m-d H:i:s'),
        ], true);
        KbFacturationSuivi::apresJournal($idOrder, $action, $ok, $msg, $ctx);
    }

    private function sel($v, $want)
    {
        return (int) $v === (int) $want ? 'selected' : '';
    }

    /* ------------------------------------------------------------------ */
    /* Fiche commande                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * Auto-réparation (une fois) : colonne `detail`, hooks 1.3, rattrapage des récaps.
     * Utile si PrestaShop a remplacé les fichiers sans exécuter upgrade/upgrade-1.3.0.php.
     */
    public function assurerSchema()
    {
        if ((int) Configuration::get('KBFACT_SCHEMA') >= 4) {
            return;
        }
        require_once __DIR__ . '/upgrade/upgrade-1.3.0.php';
        if (upgrade_module_1_3_0($this) && KbFacturationComplet::installTable()) {
            if (!Configuration::get(self::CFG_BCC_PREFIX)) {
                Configuration::updateValue(self::CFG_BCC_PREFIX, '98-98-');
            }
            Configuration::updateValue('KBFACT_SCHEMA', 4);
        }
    }

    public function hookDisplayAdminOrderSide($params)
    {
        $this->assurerSchema();
        $r = $this->ligneSuivi((int) ($params['id_order'] ?? 0));
        if (!$r) {
            return '';
        }
        $f = [$this, 'eurFr'];
        $cap = $r['captured']
            ? '<span style="color:#1a7f37;font-weight:700">Capturé ' . $f($r['captured_amount']) . '</span>'
            : '<span style="color:#b26b00;font-weight:700">Non capturé</span>';
        return '<div class="card mt-2"><div class="card-header"><h3 class="card-header-title">Facturation PDV</h3></div>'
            . '<div class="card-body" style="font-size:14px;line-height:1.7">'
            . 'Commande PDV : <b>' . Tools::safeOutput($r['pdv_commande']) . '</b><br>'
            . 'Facture PDV : <b>' . Tools::safeOutput($r['pdv_facture']) . '</b><br>'
            . 'Avoir(s) PDV : <b>' . Tools::safeOutput($r['pdv_avoirs'] ?: '—') . '</b><br>'
            . 'Montant initial : ' . $f($r['total_initial_ttc']) . '<br>'
            . 'Montant réel : <b style="font-size:16px">' . $f($r['net_ttc']) . '</b><br>'
            . 'PayZen : ' . $cap . '</div></div>'
            // récap ligne à ligne aussi ici (au cas où le thème admin n'affiche pas displayAdminOrderMainBottom)
            . (Hook::getIdByName('displayAdminOrderMainBottom') && $this->isRegisteredInHook('displayAdminOrderMainBottom') ? ''
                : '<div class="card mt-2"><div class="card-header"><h3 class="card-header-title">Ce que le client a eu</h3></div><div class="card-body" style="font-size:12px">' . $this->recapHtml($r) . '</div></div>');
    }

    /** Fiche commande (back-office), colonne principale : récap ligne à ligne, ruptures barrées */
    public function hookDisplayAdminOrderMainBottom($params)
    {
        $r = $this->ligneSuivi((int) ($params['id_order'] ?? 0));
        return $r ? '<div class="card mt-2"><div class="card-header"><h3 class="card-header-title">Récap facturation PDV — ce que le client a réellement eu</h3></div>'
            . '<div class="card-body">' . $this->recapHtml($r) . '</div></div>' : '';
    }

    /** Compte client › détail de commande : le client voit ce qui a été retiré ou ajusté */
    public function hookDisplayOrderDetail($params)
    {
        $o = $params['order'] ?? null;
        $r = $o ? $this->ligneSuivi((int) $o->id) : null;
        return $r ? '<section class="box" style="margin-top:1rem"><h3 style="font-size:1.1rem">Ajustements à la préparation</h3>'
            . '<p style="margin:.25rem 0 .75rem">Les produits barrés n\'ont pas pu vous être fournis : ils ne vous sont pas facturés.</p>'
            . $this->recapHtml($r) . '</section>' : '';
    }

    private function ligneSuivi($idOrder)
    {
        if ($idOrder <= 0) {
            return null;
        }
        return Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_order` WHERE id_order=' . (int) $idOrder) ?: null;
    }

    public function eurFr($n)
    {
        return number_format((float) $n, 2, ',', ' ') . ' €';
    }

    /** Tableau HTML : lignes retirées barrées, quantités / prix ajustés « avant → après » */
    public function recapHtml(array $r)
    {
        $lignes = json_decode((string) ($r['detail'] ?? ''), true);
        if (!is_array($lignes) || !$lignes) {
            return '<p>Montant initial ' . $this->eurFr($r['total_initial_ttc']) . ' — montant réel <b>' . $this->eurFr($r['net_ttc']) . '</b>.</p>';
        }
        $f = [$this, 'eurFr'];
        $rows = '';
        foreach ($lignes as $l) {
            $nom = Tools::safeOutput($l['nom'] ?? '');
            $e = $l['etat'] ?? 'ok';
            if ($e === 'retire') {
                $rows .= '<tr style="color:#9a9a9a"><td><s>' . $nom . '</s></td><td style="text-align:center"><s>' . (int) $l['qte_init'] . '</s> → 0</td>'
                    . '<td style="text-align:right"><s>' . $f($l['ttc_init']) . '</s></td><td style="text-align:right;color:#b42318;font-weight:700">0,00 €</td>'
                    . '<td><span style="background:#fdeceb;color:#b42318;border-radius:4px;padding:1px 6px;font-size:12px;font-weight:700">Rupture — retiré</span></td></tr>';
            } elseif ($e === 'quantite' || $e === 'remise') {
                $q = (int) $l['qte_init'] !== (int) $l['qte'] ? '<s>' . (int) $l['qte_init'] . '</s> → <b>' . (int) $l['qte'] . '</b>' : (int) $l['qte'];
                $rows .= '<tr><td>' . $nom . '</td><td style="text-align:center">' . $q . '</td>'
                    . '<td style="text-align:right"><s style="color:#9a9a9a">' . $f($l['ttc_init']) . '</s></td><td style="text-align:right;font-weight:700">' . $f($l['ttc']) . '</td>'
                    . '<td><span style="background:#fff4e5;color:#8a4b00;border-radius:4px;padding:1px 6px;font-size:12px;font-weight:700">'
                    . ($e === 'quantite' ? 'Quantité ajustée' : 'Remise') . '</span></td></tr>';
            } else {
                $rows .= '<tr><td>' . $nom . '</td><td style="text-align:center">' . (int) $l['qte'] . '</td><td style="text-align:right">' . $f($l['ttc_init']) . '</td>'
                    . '<td style="text-align:right">' . $f($l['ttc']) . '</td><td><span style="color:#1a7f37;font-size:12px">fourni</span></td></tr>';
            }
        }
        return '<table class="table" style="width:100%"><thead><tr><th>Produit</th><th style="text-align:center">Qté</th>'
            . '<th style="text-align:right">Commandé</th><th style="text-align:right">Facturé</th><th></th></tr></thead><tbody>' . $rows
            . '</tbody><tfoot><tr><td colspan="2"><b>Total</b> (frais de port et réductions compris)</td><td style="text-align:right"><s style="color:#9a9a9a">'
            . $f($r['total_initial_ttc']) . '</s></td><td style="text-align:right;font-size:16px"><b>' . $f($r['net_ttc']) . '</b></td><td></td></tr></tfoot></table>';
    }
}
