<?php
/**
 * kbhoraires — API signée (appli Kelbongoo via Cloud Function kbgReglesCommandes).
 * POST JSON + en-tête X-KBG-Signature = HMAC-SHA256(corps brut, secret du module kbfacturation).
 * Actions : lire | ecrire
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbhorairesApiModuleFrontController extends ModuleFrontController
{
    public $auth = false;
    public $ajax = true;
    public $ssl = true;

    protected function displayMaintenancePage()
    {
    }

    protected function displayRestrictedCountryPage()
    {
    }

    protected function sortie($code, array $data)
    {
        http_response_code($code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    public function init()
    {
        parent::init();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            $this->sortie(405, ['ok' => false, 'erreur' => 'POST uniquement']);
        }
        $raw = (string) file_get_contents('php://input');
        $secret = trim((string) Configuration::get('KBFACT_SECRET'));
        $sig = strtolower(trim((string) ($_SERVER['HTTP_X_KBG_SIGNATURE'] ?? '')));
        if ($secret === '' || strlen($raw) > 50000 || !hash_equals(hash_hmac('sha256', $raw, $secret), $sig)) {
            $this->sortie(401, ['ok' => false, 'erreur' => 'signature']);
        }
        $p = json_decode($raw, true);
        if (!is_array($p)) {
            $this->sortie(400, ['ok' => false, 'erreur' => 'JSON invalide']);
        }
        if (abs(time() - (int) ($p['ts'] ?? 0)) > 600) {
            $this->sortie(400, ['ok' => false, 'erreur' => 'horodatage expiré (ts)']);
        }
        try {
            $action = (string) ($p['action'] ?? '');
            if ($action === 'lire') {
                $this->sortie(200, $this->module->etat());
            }
            if ($action === 'ecrire') {
                $this->sortie(200, $this->module->ecrire((array) ($p['regles'] ?? []), (string) ($p['by'] ?? 'appli')));
            }
            $this->sortie(400, ['ok' => false, 'erreur' => 'action inconnue']);
        } catch (\Throwable $e) {
            $this->sortie(500, ['ok' => false, 'erreur' => $e->getMessage()]);
        }
    }
}
