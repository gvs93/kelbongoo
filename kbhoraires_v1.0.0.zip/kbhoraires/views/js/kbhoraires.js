/* kbhoraires — masque les jours de retrait dont les commandes ne sont pas encore ouvertes (Prestatill).
   Défensif : en cas de souci, ne fait rien (le garde-fou serveur à l'étape paiement reste actif). */
(function () {
  'use strict';
  var C = window.KBH || {};
  var R = C.rules || {};
  var load = Date.now();
  var JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var MONTHS = { jan: 1, janv: 1, janvier: 1, fev: 2, fevr: 2, fevrier: 2, feb: 2, mar: 3, mars: 3, avr: 4, avril: 4, apr: 4, mai: 5, may: 5,
    juin: 6, jun: 6, juil: 7, juillet: 7, jul: 7, aou: 8, aout: 8, aug: 8, sep: 9, sept: 9, septembre: 9, oct: 10, octobre: 10,
    nov: 11, novembre: 11, dec: 12, decembre: 12 };

  function now() { return (C.serverNow || load) + (Date.now() - load); }
  function norm(s) { s = String(s || '').toLowerCase(); try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) {} return s; }
  function pad(n) { return ('0' + n).slice(-2); }
  function withYear(m, d, y) {
    if (!(m >= 1 && m <= 12 && d >= 1 && d <= 31)) { return null; }
    if (!y) { var t = new Date(); y = t.getFullYear(); if (m < t.getMonth() + 1 - 6) { y++; } }
    if (y < 100) { y += 2000; }
    return y + '-' + pad(m) + '-' + pad(d);
  }
  function parseLoose(s) {
    s = norm(s);
    if (!s || s === '-1') { return null; }
    var m = s.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (m) { return m[1] + '-' + m[2] + '-' + m[3]; }
    m = s.match(/(\d{1,2})\s*[\/.]\s*(\d{1,2})(?:\s*[\/.]\s*(\d{2,4}))?/);
    if (m) { return withYear(+m[2], +m[1], m[3] ? +m[3] : 0); }
    m = s.match(/(\d{1,2})\s+([a-z]+)\.?(?:\s+(\d{4}))?/);
    if (m && MONTHS[m[2]]) { return withYear(MONTHS[m[2]], +m[1], m[3] ? +m[3] : 0); }
    return null;
  }
  /* Instant (ms UTC) d'ouverture des commandes pour le jour de retrait ymd ; 0 = pas de règle. */
  function openAt(ymd) {
    var p = ymd.split('-'), y = +p[0], mo = +p[1] - 1, d = +p[2];
    var wd = new Date(Date.UTC(y, mo, d)).getUTCDay();
    var r = R[String(wd)];
    if (!r) { return 0; }
    var diff = (wd - r.wd + 7) % 7 || 7;
    return Date.UTC(y, mo, d - diff, r.h || 0, 0, 0) - (C.offsetMin || 60) * 60000;
  }
  function isOpen(ymd) { var o = openAt(ymd); return !o || now() >= o; }
  function frOpen(ymd) {
    var o = openAt(ymd) + (C.offsetMin || 60) * 60000, d = new Date(o);
    return JOURS[d.getUTCDay()] + ' ' + pad(d.getUTCDate()) + '/' + pad(d.getUTCMonth() + 1) + (d.getUTCHours() ? ' à ' + d.getUTCHours() + 'h' : '');
  }
  function frDay(ymd) { var p = ymd.split('-'); return JOURS[new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay()] + ' ' + p[2] + '/' + p[1]; }

  function apply() {
    var box = document.getElementById('table_box') || document.getElementById('table_dispo');
    if (!box) { return; }
    var next = null;
    var slots = box.querySelectorAll('[data-datetime]');
    for (var i = 0; i < slots.length; i++) {
      var d = String(slots[i].getAttribute('data-datetime') || '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) { continue; }
      if (!isOpen(d)) {
        if (!next || d < next) { next = d; }
        if (!slots[i].classList.contains('kbh-closed') || slots[i].classList.contains('dispo')) {
          slots[i].classList.remove('dispo', 'selected', 'active');
          slots[i].classList.add('indispo', 'kbh-closed');
        }
      }
    }
    var heads = box.querySelectorAll('#list_creneau span[data-date], #list_creneau td[data-date]');
    for (var h = 0; h < heads.length; h++) {
      var hd = parseLoose(heads[h].getAttribute('data-date'));
      if (hd && !isOpen(hd)) { heads[h].classList.add('kbh-closed', 'disabled'); if (!next || hd < next) { next = hd; } }
    }
    var sels = box.querySelectorAll('select#list_creneau, select.viewList');
    for (var s = 0; s < sels.length; s++) {
      var sel = sels[s], reset = false;
      for (var o = 0; o < sel.options.length; o++) {
        var opt = sel.options[o];
        if (opt.getAttribute('data-date') === '-1') { continue; }
        var od = parseLoose(opt.getAttribute('data-date')) || parseLoose(opt.text);
        if (od && !isOpen(od)) {
          if (!next || od < next) { next = od; }
          if (!opt.disabled || !opt.hidden) { opt.disabled = true; opt.hidden = true; if (opt.selected) { reset = true; } }
        }
      }
      if (reset) { sel.selectedIndex = 0; try { if (window.jQuery) { window.jQuery(sel).trigger('change'); } } catch (e) {} }
    }
    var note = box.querySelector('.kbh-note');
    if (next) {
      var txt = 'ℹ️ Les commandes pour ' + frDay(next) + ' ouvrent ' + frOpen(next) + '.';
      if (!note) { note = document.createElement('div'); note.className = 'kbh-note'; box.insertBefore(note, box.firstChild); }
      if (note.textContent !== txt) { note.textContent = txt; }
    } else if (note && note.parentNode) { note.parentNode.removeChild(note); }
  }

  var t = null, busy = false;
  function run() { if (busy) { return; } busy = true; try { apply(); } catch (e) { if (window.console) { console.warn('[kbhoraires]', e); } } busy = false; }
  function boot() {
    run();
    try { new MutationObserver(function () { if (!busy) { if (t) { clearTimeout(t); } t = setTimeout(run, 70); } }).observe(document.body, { childList: true, subtree: true }); } catch (e) {}
    setInterval(run, 60000);
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();
