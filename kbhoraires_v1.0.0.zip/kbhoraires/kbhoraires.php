<?php
/**
 * Kelbongoo - Horaires de commande (kbhoraires)
 *
 * Règles d'OUVERTURE et de CLÔTURE des commandes, pilotées depuis l'appli Kelbongoo (Master) :
 *  - Ouverture : un jour de retrait n'est commandable qu'à partir d'un jour/heure donnés
 *    (ex. mercredi et jeudi : à partir du vendredi précédent ; vendredi et samedi : à partir du mardi).
 *  - Clôture : heure limite + nombre de jours avant (réglages du module kbtunnel, KBT_CUTOFF_*),
 *    modifiables ici et depuis l'appli.
 *  - Mode TEST : lève ouverture ET clôture (tous les créneaux commandables) — à couper après les essais.
 *
 * Click & Collect (Prestatill) : créneaux pas encore ouverts masqués + garde-fou serveur à l'étape paiement
 * + note interne si une commande passe quand même. Aucun override, aucune table.
 * API signée (HMAC, même secret que kbfacturation) : controllers/front/api.php — actions lire / ecrire.
 *
 * @author  Kelbongoo
 * @version 1.0.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Kbhoraires extends Module
{
    const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    // jour de retrait (0 = dimanche) => jour d'ouverture + heure
    const RULES_DEF = '{"3":{"wd":5,"h":0},"4":{"wd":5,"h":0},"5":{"wd":2,"h":0},"6":{"wd":2,"h":0}}';

    public function __construct()
    {
        $this->name = 'kbhoraires';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Kelbongoo';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => '9.99.99'];
        parent::__construct();
        $this->displayName = $this->l('Kelbongoo - Horaires de commande');
        $this->description = $this->l('Ouverture des commandes par jour de retrait, heure limite, mode test — pilotés depuis l\'appli Kelbongoo.');
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayPaymentTop')
            && $this->registerHook('actionValidateOrder')
            && Configuration::updateValue('KBH_OPEN_ON', '1')
            && Configuration::updateValue('KBH_OPEN_RULES', self::RULES_DEF)
            && Configuration::updateValue('KBH_TEST', '0');
    }

    public function uninstall()
    {
        if ((int) Configuration::get('KBH_TEST') === 1) {
            $this->setTest(false);
        }
        foreach (['KBH_OPEN_ON', 'KBH_OPEN_RULES', 'KBH_TEST', 'KBH_PREV_CUTOFF_ON', 'KBH_LOG'] as $k) {
            Configuration::deleteByName($k);
        }
        return parent::uninstall();
    }

    /* ============================================================ RÉGLAGES */

    public function tz()
    {
        $n = (string) Configuration::get('PS_TIMEZONE');
        try {
            return new DateTimeZone($n !== '' ? $n : 'Europe/Paris');
        } catch (\Throwable $e) {
            return new DateTimeZone('Europe/Paris');
        }
    }

    public function rules()
    {
        $r = json_decode((string) (Configuration::get('KBH_OPEN_RULES') ?: self::RULES_DEF), true);
        $out = [];
        foreach ((array) $r as $wd => $x) {
            $wd = (int) $wd;
            if ($wd < 0 || $wd > 6 || !is_array($x) || !isset($x['wd'])) {
                continue;
            }
            $out[(string) $wd] = ['wd' => max(0, min(6, (int) $x['wd'])), 'h' => max(0, min(23, (int) ($x['h'] ?? 0)))];
        }
        return $out;
    }

    public function isTest()
    {
        return (int) Configuration::get('KBH_TEST') === 1;
    }

    public function openActive()
    {
        return (int) Configuration::get('KBH_OPEN_ON') === 1 && !$this->isTest();
    }

    /** Instant d'ouverture (timestamp) des commandes pour le jour de retrait $ymd ; 0 = pas de règle. */
    public function openTs($ymd)
    {
        $rules = $this->rules();
        try {
            $d = new DateTime($ymd . ' 00:00:00', $this->tz());
        } catch (\Throwable $e) {
            return 0;
        }
        $wd = (int) $d->format('w');
        if (!isset($rules[(string) $wd])) {
            return 0;
        }
        $r = $rules[(string) $wd];
        $diff = ($wd - $r['wd'] + 7) % 7;
        if ($diff === 0) {
            $diff = 7;
        }
        $d->modify('-' . $diff . ' day');
        $d->setTime($r['h'], 0, 0);
        return $d->getTimestamp();
    }

    public function isOpen($ymd, $nowTs = null)
    {
        if (!$this->openActive()) {
            return true;
        }
        $o = $this->openTs($ymd);
        return $o === 0 || ($nowTs === null ? time() : (int) $nowTs) >= $o;
    }

    public function frDate($ymd)
    {
        $ts = strtotime($ymd . ' 12:00:00');
        return $ts ? self::JOURS[(int) date('w', $ts)] . ' ' . date('d/m', $ts) : $ymd;
    }

    public function frTs($ts)
    {
        $d = new DateTime('@' . (int) $ts);
        $d->setTimezone($this->tz());
        return self::JOURS[(int) $d->format('w')] . ' ' . $d->format('d/m') . ((int) $d->format('G') ? ' à ' . (int) $d->format('G') . 'h' : '');
    }

    /** Mode test : lève aussi la clôture de kbtunnel (valeur précédente mémorisée et restaurée). */
    public function setTest($on)
    {
        $on = (bool) $on;
        if ($on === $this->isTest()) {
            return;
        }
        if ($on) {
            $prev = Configuration::get('KBT_CUTOFF_ON');
            Configuration::updateValue('KBH_PREV_CUTOFF_ON', ($prev === false || $prev === null) ? '1' : (string) (int) $prev);
            Configuration::updateValue('KBT_CUTOFF_ON', '0');
        } else {
            $prev = Configuration::get('KBH_PREV_CUTOFF_ON');
            Configuration::updateValue('KBT_CUTOFF_ON', ($prev === false || $prev === null || $prev === '') ? '1' : (string) (int) $prev);
            Configuration::deleteByName('KBH_PREV_CUTOFF_ON');
        }
        Configuration::updateValue('KBH_TEST', $on ? '1' : '0');
    }

    /** État complet (lu par l'appli). */
    public function etat()
    {
        $kbt = Module::getInstanceByName('kbtunnel');
        $cutOn = $this->isTest() ? (int) (Configuration::get('KBH_PREV_CUTOFF_ON') ?: 1) : (int) (Configuration::get('KBT_CUTOFF_ON') === false ? 1 : Configuration::get('KBT_CUTOFF_ON'));
        $hour = Configuration::get('KBT_CUTOFF_HOUR');
        $days = Configuration::get('KBT_CUTOFF_DAYS');
        $e = [
            'ok' => true,
            'module' => $this->version,
            'kbtunnel' => $kbt ? (string) $kbt->version : null,
            'kbtunnel_actif' => $kbt ? (bool) Module::isEnabled('kbtunnel') : false,
            'test' => $this->isTest(),
            'cutoff_on' => (bool) $cutOn,
            'cutoff_effectif' => !$this->isTest() && (bool) $cutOn,
            'cutoff_hour' => ($hour === false || $hour === null || $hour === '') ? 10 : (int) $hour,
            'cutoff_days' => ($days === false || $days === null || $days === '') ? 1 : (int) $days,
            'open_on' => (int) Configuration::get('KBH_OPEN_ON') === 1,
            'open_rules' => $this->rules(),
            'maintenant' => (new DateTime('now', $this->tz()))->format('Y-m-d H:i'),
            'jours' => [],
            'log' => json_decode((string) Configuration::get('KBH_LOG'), true) ?: [],
        ];
        // 14 prochains jours : ouvert ? clos ?
        $earliest = null;
        if ($kbt && method_exists($kbt, 'cutoffInfo') && $e['cutoff_effectif']) {
            try {
                $ci = $kbt->cutoffInfo();
                $earliest = $ci['earliest'];
            } catch (\Throwable $x) {
            }
        }
        $d = new DateTime('today', $this->tz());
        for ($i = 0; $i < 14; $i++) {
            $ymd = $d->format('Y-m-d');
            $o = $this->openTs($ymd);
            $e['jours'][] = [
                'jour' => $ymd, 'libelle' => $this->frDate($ymd),
                'ouvert' => $this->isOpen($ymd),
                'ouverture' => ($o && $this->openActive()) ? $this->frTs($o) : null,
                'clos' => $earliest !== null && $ymd < $earliest,
            ];
            $d->modify('+1 day');
        }
        return $e;
    }

    /** Enregistre les réglages venus de l'appli (ou du back-office). */
    public function ecrire(array $p, $by = '')
    {
        if (array_key_exists('cutoff_hour', $p)) {
            Configuration::updateValue('KBT_CUTOFF_HOUR', (string) max(0, min(23, (int) $p['cutoff_hour'])));
        }
        if (array_key_exists('cutoff_days', $p)) {
            Configuration::updateValue('KBT_CUTOFF_DAYS', (string) max(0, min(14, (int) $p['cutoff_days'])));
        }
        if (array_key_exists('cutoff_on', $p)) {
            $v = !empty($p['cutoff_on']) ? '1' : '0';
            if ($this->isTest()) {
                Configuration::updateValue('KBH_PREV_CUTOFF_ON', $v);
            } else {
                Configuration::updateValue('KBT_CUTOFF_ON', $v);
            }
        }
        if (array_key_exists('open_on', $p)) {
            Configuration::updateValue('KBH_OPEN_ON', !empty($p['open_on']) ? '1' : '0');
        }
        if (isset($p['open_rules']) && is_array($p['open_rules'])) {
            $clean = [];
            foreach ($p['open_rules'] as $wd => $x) {
                $wd = (int) $wd;
                if ($wd >= 0 && $wd <= 6 && is_array($x) && isset($x['wd']) && $x['wd'] !== '' && $x['wd'] !== null) {
                    $clean[(string) $wd] = ['wd' => max(0, min(6, (int) $x['wd'])), 'h' => max(0, min(23, (int) ($x['h'] ?? 0)))];
                }
            }
            Configuration::updateValue('KBH_OPEN_RULES', json_encode($clean));
        }
        if (array_key_exists('test', $p)) {
            $this->setTest(!empty($p['test']));
        }
        $log = json_decode((string) Configuration::get('KBH_LOG'), true) ?: [];
        array_unshift($log, ['at' => (new DateTime('now', $this->tz()))->format('Y-m-d H:i'), 'by' => Tools::substr((string) $by, 0, 60),
            'test' => $this->isTest(), 'h' => (int) Configuration::get('KBT_CUTOFF_HOUR')]);
        Configuration::updateValue('KBH_LOG', json_encode(array_slice($log, 0, 15), JSON_UNESCAPED_UNICODE));
        return $this->etat();
    }

    /* ============================================================ FRONT */

    protected function isOrderPage()
    {
        $c = $this->context->controller;
        return isset($c->php_self) && $c->php_self === 'order';
    }

    public function hookDisplayHeader($params)
    {
        try {
            if (!$this->isOrderPage() || !$this->openActive()) {
                return '';
            }
            $js = @file_get_contents(_PS_MODULE_DIR_ . $this->name . '/views/js/kbhoraires.js');
            if ($js === false) {
                return '';
            }
            $tz = $this->tz();
            $cfg = [
                'rules' => $this->rules(),
                'serverNow' => time() * 1000,
                'offsetMin' => (int) round($tz->getOffset(new DateTime('now', $tz)) / 60),
            ];
            $json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
            return '<style>.kbh-closed{display:none !important}#list_creneau option[hidden]{display:none}'
                . '.kbh-note{margin:0 0 10px;padding:8px 12px;border-radius:8px;background:#fff8e1;color:#7a5b00;font-size:13px;line-height:1.4}</style>'
                . '<script>window.KBH=' . $json . ";\n" . $js . '</script>';
        } catch (\Throwable $e) {
            return '';
        }
    }

    protected function cartSlotDay($idCart)
    {
        try {
            $r = Db::getInstance()->executeS('SHOW TABLES LIKE \'' . pSQL(_DB_PREFIX_ . 'prestatill_drive_creneau') . '\'');
            if (empty($r)) {
                return null;
            }
            $day = Db::getInstance()->getValue('SELECT day FROM ' . _DB_PREFIX_ . 'prestatill_drive_creneau WHERE id_cart=' . (int) $idCart);
            $day = substr((string) $day, 0, 10);
            return preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) && $day !== '0000-00-00' ? $day : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function hookDisplayPaymentTop($params)
    {
        try {
            if (!$this->openActive()) {
                return '';
            }
            $cart = $this->context->cart;
            if (!Validate::isLoadedObject($cart)) {
                return '';
            }
            $day = $this->cartSlotDay($cart->id);
            if (!$day || $this->isOpen($day)) {
                return '';
            }
            return '<div class="kbt-block kbt-block--cutoff" style="margin:0 0 16px;padding:14px 16px;border-radius:10px;background:#fdecea;border:1px solid #f5c2bd;color:#8e1c12">⛔ '
                . htmlspecialchars('Les commandes pour ' . $this->frDate($day) . ' ne sont pas encore ouvertes (ouverture ' . $this->frTs($this->openTs($day)) . '). Merci de choisir un autre jour de retrait.')
                . '</div><style>#checkout-payment-step .payment-options,#checkout-payment-step #payment-confirmation,#checkout-payment-step .js-payment-confirmation,'
                . '#checkout-payment-step #conditions-to-approve,#checkout-payment-step .payment__list,#checkout-payment-step [id^="payment-option-"]{display:none !important;}</style>';
        } catch (\Throwable $e) {
            return '';
        }
    }

    public function hookActionValidateOrder($params)
    {
        try {
            if (!$this->openActive() || empty($params['order']) || empty($params['cart'])) {
                return;
            }
            $day = $this->cartSlotDay($params['cart']->id);
            if (!$day || $this->isOpen($day)) {
                return;
            }
            $m = new Message();
            $m->id_order = (int) $params['order']->id;
            $m->id_cart = (int) $params['cart']->id;
            $m->id_customer = (int) $params['order']->id_customer;
            $m->private = 1;
            $m->message = '⚠️ Commande passée AVANT l\'ouverture des commandes du ' . $this->frDate($day) . '. À vérifier.';
            $m->add();
        } catch (\Throwable $e) {
        }
    }

    /* ============================================================ BACK-OFFICE */

    public function getContent()
    {
        $out = '';
        if (Tools::isSubmit('submitKbh')) {
            $rules = [];
            for ($wd = 0; $wd <= 6; $wd++) {
                $o = Tools::getValue('open_wd_' . $wd, '');
                if ($o !== '' && $o !== null) {
                    $rules[(string) $wd] = ['wd' => (int) $o, 'h' => (int) Tools::getValue('open_h_' . $wd, 0)];
                }
            }
            $this->ecrire([
                'cutoff_on' => (int) Tools::getValue('cutoff_on'), 'cutoff_hour' => (int) Tools::getValue('cutoff_hour', 10),
                'cutoff_days' => (int) Tools::getValue('cutoff_days', 1), 'open_on' => (int) Tools::getValue('open_on'),
                'open_rules' => $rules, 'test' => (int) Tools::getValue('test'),
            ], 'back-office ' . (isset($this->context->employee) ? $this->context->employee->email : ''));
            $out .= $this->displayConfirmation('Réglages enregistrés. Videz le cache si besoin.');
        }
        $e = $this->etat();
        $h = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES); };
        $sel = function ($name, $val, $empty) use ($h) {
            $s = '<select name="' . $h($name) . '" class="form-control" style="display:inline-block;width:auto">' . ($empty ? '<option value="">— pas de règle —</option>' : '');
            foreach (self::JOURS as $i => $j) {
                $s .= '<option value="' . $i . '"' . ((string) $val === (string) $i ? ' selected' : '') . '>' . $h($j) . '</option>';
            }
            return $s . '</select>';
        };
        $out .= '<div class="panel"><h3>Horaires de commande</h3>';
        if ($e['test']) {
            $out .= '<div class="alert alert-warning"><b>MODE TEST ACTIF</b> : ouverture et clôture levées, tous les créneaux sont commandables.</div>';
        }
        $out .= '<p>Réglages normalement pilotés depuis l\'appli Kelbongoo (Master › Horaires de commande). kbtunnel : <b>' . $h($e['kbtunnel'] ?: 'absent') . '</b></p>'
            . '<form method="post" action="' . $h(AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules')) . '">'
            . '<p><label><input type="checkbox" name="test" value="1"' . ($e['test'] ? ' checked' : '') . '> <b>Mode test</b> (tout commandable)</label></p>'
            . '<p><label><input type="checkbox" name="cutoff_on" value="1"' . ($e['cutoff_on'] ? ' checked' : '') . '> Clôture</label> : '
            . '<input name="cutoff_days" value="' . (int) $e['cutoff_days'] . '" style="width:50px"> jour(s) avant, à '
            . '<input name="cutoff_hour" value="' . (int) $e['cutoff_hour'] . '" style="width:50px"> h</p>'
            . '<p><label><input type="checkbox" name="open_on" value="1"' . ($e['open_on'] ? ' checked' : '') . '> Ouverture des commandes</label></p><table class="table" style="width:auto">';
        for ($wd = 1; $wd <= 7; $wd++) {
            $w = $wd % 7;
            $r = $e['open_rules'][(string) $w] ?? null;
            $out .= '<tr><td>Retrait <b>' . $h(self::JOURS[$w]) . '</b></td><td>ouvre le ' . $sel('open_wd_' . $w, $r ? $r['wd'] : '', true)
                . ' à <input name="open_h_' . $w . '" value="' . (int) ($r ? $r['h'] : 0) . '" style="width:50px"> h</td></tr>';
        }
        $out .= '</table><button type="submit" name="submitKbh" class="btn btn-primary">Enregistrer</button></form>'
            . '<h4 style="margin-top:20px">14 prochains jours</h4><table class="table" style="width:auto">';
        foreach ($e['jours'] as $j) {
            $out .= '<tr><td>' . $h($j['libelle']) . '</td><td>' . ($j['clos'] ? '🔒 clos' : ($j['ouvert'] ? '✅ commandable' : '⏳ ouvre ' . $h($j['ouverture']))) . '</td></tr>';
        }
        return $out . '</table></div>';
    }
}
