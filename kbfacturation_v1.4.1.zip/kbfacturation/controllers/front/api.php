<?php
/**
 * Point d'entrée signé : POST JSON + en-tête X-KBG-Signature = HMAC-SHA256(corps brut, secret du module).
 * Actions : appliquer | capturer | etat
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbfacturationApiModuleFrontController extends ModuleFrontController
{
    public $auth = false;
    public $ajax = true;
    public $ssl = true;

    // API serveur à serveur : jamais de page de maintenance / restriction pays
    protected function displayMaintenancePage()
    {
    }

    protected function displayRestrictedCountryPage()
    {
    }

    public function init()
    {
        parent::init();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');

        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            $this->sortie(405, ['ok' => false, 'erreur' => 'POST uniquement']);
        }
        $raw = (string) file_get_contents('php://input');
        $secret = (string) Configuration::get(Kbfacturation::CFG_SECRET);
        $sig = strtolower(trim((string) ($_SERVER['HTTP_X_KBG_SIGNATURE'] ?? '')));
        if ($secret === '' || strlen($raw) > 200000 || !hash_equals(hash_hmac('sha256', $raw, $secret), $sig)) {
            $this->journal(null, 'auth', false, 'Signature invalide depuis ' . Tools::getRemoteAddr(), null);
            $this->sortie(401, ['ok' => false, 'erreur' => 'signature']);
        }
        $p = json_decode($raw, true);
        if (!is_array($p)) {
            $this->sortie(400, ['ok' => false, 'erreur' => 'JSON invalide']);
        }
        if (abs(time() - (int) ($p['ts'] ?? 0)) > 600) {
            $this->sortie(400, ['ok' => false, 'erreur' => 'horodatage expiré (ts)']);
        }

        $action = (string) ($p['action'] ?? '');
        $svc = new KbFacturationService($this->module);
        $idOrder = null;
        try {
            $order = $svc->loadOrder($p);
            $idOrder = (int) $order->id;
            switch ($action) {
                case 'appliquer':
                    $r = $svc->appliquer($p);
                    break;
                case 'appliquer_pdv':
                    // Le module relit lui-même la facture et les avoirs dans PDV (API G5)
                    $pdv = (array) ($p['pdv'] ?? []);
                    $etat = (new KbFacturationG5())->etatFinal((string) ($pdv['facture'] ?? ''), array_values(array_filter((array) ($pdv['avoirs'] ?? []))));
                    $p['net_ttc'] = $etat['net_ttc'];
                    $p['lignes'] = $etat['lignes'];
                    $r = $svc->appliquer($p);
                    $r['client_pdv'] = $etat['client'];
                    $r['lignes_pdv'] = $etat['lignes'];
                    break;
                case 'facturer':
                    // Chaîne complète : facture PDV + avoir des écarts + site au montant réel + PayZen
                    $r = (new KbFacturationComplet($this->module))->facturer($p);
                    break;
                case 'capturer':
                    $pz = new KbFacturationPayzen();
                    $r = $pz->capturer($order, $svc, $p['uuid'] ?? null);
                    break;
                case 'lire_pdv':
                    $pdv = (array) ($p['pdv'] ?? []);
                    $r = (new KbFacturationG5())->etatFinal((string) ($pdv['facture'] ?? ''), array_values(array_filter((array) ($pdv['avoirs'] ?? []))));
                    break;
                case 'etat':
                    $r = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_order` WHERE id_order=' . $idOrder) ?: ['statut' => 'non_applique'];
                    $r['total_paid_tax_incl'] = (float) $order->total_paid_tax_incl;
                    $r['id_order_state'] = (int) $order->getCurrentState();
                    break;
                default:
                    throw new KbFacturationException('Action inconnue');
            }
            if ($action !== 'etat' && $action !== 'lire_pdv') {
                $this->journal($idOrder, $action, true, json_encode($r, JSON_UNESCAPED_UNICODE), $raw);
            }
            $this->sortie(200, ['ok' => true, 'resultat' => $r]);
        } catch (KbFacturationException $e) {
            $this->journal($idOrder, $action ?: '?', false, $e->getMessage(), $raw);
            $this->sortie(422, ['ok' => false, 'erreur' => $e->getMessage()]);
        } catch (Throwable $e) {
            $this->journal($idOrder, $action ?: '?', false, 'Erreur interne : ' . $e->getMessage(), $raw);
            $this->sortie(500, ['ok' => false, 'erreur' => 'interne : ' . $e->getMessage()]);
        }
    }

    private function journal($idOrder, $action, $ok, $msg, $payload)
    {
        Db::getInstance()->insert('kbfact_log', [
            'id_order' => $idOrder ? (int) $idOrder : null,
            'action' => pSQL(Tools::substr($action, 0, 20)),
            'ok' => $ok ? 1 : 0,
            'message' => pSQL(Tools::substr((string) $msg, 0, 60000)),
            'payload' => $payload === null ? null : pSQL(Tools::substr($payload, 0, 200000)),
            'date_add' => date('Y-m-d H:i:s'),
        ], true);
        if ($action !== 'auth') { // pas d'envoi pour les signatures refusées (anti-flood)
            KbFacturationSuivi::apresJournal($idOrder, $action, $ok, $msg, $payload);
        }
    }

    private function sortie($code, array $data)
    {
        http_response_code($code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}
