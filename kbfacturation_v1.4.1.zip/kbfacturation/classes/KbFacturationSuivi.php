<?php
/**
 * Envoi du journal vers le suivi Master de l'appli Kelbongoo (Cloud Function kbgFactuLog).
 * Best-effort : un échec d'envoi ne bloque JAMAIS la facturation (le journal local fait foi).
 * Corps JSON signé HMAC-SHA256 avec le secret du module (en-tête X-KBG-Signature).
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbFacturationSuivi
{
    /**
     * Construit un événement à partir d'une ligne de journal.
     */
    public static function evenement($idLog, $idOrder, $action, $ok, $message, $payload, $date = null)
    {
        $ctx = is_string($payload) ? json_decode($payload, true) : (is_array($payload) ? $payload : null);
        $message = (string) $message;
        $operateur = '';
        if (preg_match('/^(.*) \[([^\]\s]+@[^\]\s]+)\]$/s', $message, $m)) { // « … [email employé] » (actions manuelles)
            $message = $m[1];
            $operateur = $m[2];
        }
        $res = json_decode($message, true);
        $ref = '';
        if (is_array($res) && !empty($res['reference'])) {
            $ref = (string) $res['reference'];
        } elseif (is_array($ctx) && !empty($ctx['reference'])) {
            $ref = (string) $ctx['reference'];
        } elseif ($idOrder) {
            $o = new Order((int) $idOrder);
            $ref = Validate::isLoadedObject($o) ? (string) $o->reference : '';
        }
        $pdv = is_array($ctx) ? (array) ($ctx['pdv'] ?? []) : [];
        return [
            'uid' => 'ps-' . (int) $idLog,
            'source' => 'prestashop',
            'date' => $date ?: date('Y-m-d H:i:s'),
            'id_order' => $idOrder ? (int) $idOrder : null,
            'reference' => strtoupper($ref),
            'action' => (string) $action,
            'operateur' => $operateur,
            'ok' => (bool) $ok,
            'message' => is_array($res) ? '' : Tools::substr((string) $message, 0, 2000),
            'resultat' => is_array($res) ? $res : null,
            'pdv_commande' => (string) ($pdv['commande'] ?? ($res['pdv_commande'] ?? '')),
            'pdv_facture' => (string) ($pdv['facture'] ?? ''),
            'pdv_avoirs' => array_values(array_map('strval', (array) ($pdv['avoirs'] ?? []))),
        ];
    }

    /**
     * Envoie des événements. Retourne [ok(bool), info(string)].
     */
    public static function envoyer(array $events, $timeout = 3)
    {
        $url = trim((string) Configuration::get(Kbfacturation::CFG_LOG_URL));
        $secret = (string) Configuration::get(Kbfacturation::CFG_SECRET);
        if ($url === '' || $secret === '' || !$events) {
            return [false, 'suivi non configuré'];
        }
        $body = json_encode(['ts' => time(), 'events' => array_values($events)], JSON_UNESCAPED_UNICODE);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8', 'X-KBG-Signature: ' . hash_hmac('sha256', $body, $secret)],
            CURLOPT_POSTFIELDS => $body,
        ]);
        $raw = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === false) {
            return [false, 'injoignable : ' . $err];
        }
        return [$code === 200, 'HTTP ' . $code . ' ' . Tools::substr((string) $raw, 0, 200)];
    }

    /**
     * Après chaque écriture de journal : pousse la ligne (sans jamais lever d'exception).
     */
    public static function apresJournal($idOrder, $action, $ok, $message, $payload)
    {
        try {
            $id = (int) Db::getInstance()->Insert_ID();
            self::envoyer([self::evenement($id, $idOrder, $action, $ok, $message, $payload)]);
        } catch (Throwable $e) {
            // silencieux : le journal local reste la référence
        }
    }

    /**
     * Renvoie l'historique local (rattrapage). Idempotent côté app (uid = ps-<id_log>).
     */
    public static function renvoyerHistorique($limite = 500)
    {
        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_log` ORDER BY id_log DESC LIMIT ' . (int) $limite
        ) ?: [];
        $ev = [];
        foreach (array_reverse($rows) as $l) {
            $ev[] = self::evenement($l['id_log'], $l['id_order'], $l['action'], $l['ok'], $l['message'], $l['payload'], $l['date_add']);
        }
        $n = 0;
        foreach (array_chunk($ev, 100) as $lot) {
            [$ok, $info] = self::envoyer($lot, 15);
            if (!$ok) {
                return [false, $n . ' envoyés puis échec : ' . $info];
            }
            $n += count($lot);
        }
        return [true, $n . ' événement(s) envoyé(s)'];
    }
}
