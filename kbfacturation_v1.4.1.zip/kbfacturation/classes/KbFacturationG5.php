<?php
/**
 * Lecture des documents PDV via l'API SOAP G5 Progmag (lecture seule : chargerDocument).
 * PrestaShop joint le serveur G5 (même chemin que le module connecteur_pdv).
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbFacturationG5
{
    private $base;

    public function __construct()
    {
        $this->base = rtrim((string) Configuration::get(Kbfacturation::CFG_G5_URL), '/') . '/';
    }

    /**
     * @return array ['client'=>, 'ttc'=>float, 'lignes'=>[[article,qte,total_ttc,designation]], 'port'=>float]
     */
    public function document($type, $numero)
    {
        if (!preg_match('/^[0-9A-Za-z\-]{3,32}$/', $numero) || !in_array($type, ['FAC', 'BCC', 'BLC'], true)) {
            throw new KbFacturationException('Document PDV invalide : ' . $type . ' ' . $numero);
        }
        $inner = '<d:chargerDocumentDemande version="1.1" numeroDocument="' . $numero . '"><typeDocument code="' . $type . '"/></d:chargerDocumentDemande>';
        $xml = $this->appel('historiqueClient', 'chargerDocument', $inner);
        $sx = @simplexml_load_string($xml);
        if ($sx === false) {
            throw new KbFacturationException('Réponse G5 illisible pour ' . $type . ' ' . $numero);
        }
        $ent = $sx->xpath('//*[local-name()="entete"]');
        if (!$ent) {
            $f = $sx->xpath('//*[local-name()="faultstring"]');
            throw new KbFacturationException('PDV : ' . ($f ? (string) $f[0] : 'document ' . $type . ' ' . $numero . ' introuvable'));
        }
        $e = $ent[0]->attributes();
        $lignes = [];
        $port = 0.0;
        foreach ($sx->xpath('//*[local-name()="ligne"]') as $l) {
            $a = $l->attributes();
            $art = trim((string) $a['codeArticle']);
            if ($art === '') {
                continue; // ligne commentaire (créneau)
            }
            $tot = (float) $a['totalVenteTTCPied'];
            if (strtoupper($art) === 'PORT') {
                $port += $tot;
                continue;
            }
            $lignes[] = ['article' => $art, 'qte' => (float) $a['quantite'], 'total_ttc' => $tot, 'designation' => (string) $a['designation']];
        }
        return ['client' => (string) $e['client'], 'ttc' => (float) $e['montantTotalTTC'], 'lignes' => $lignes, 'port' => $port,
                'date' => (string) $e['dateDocument']];
    }

    /**
     * Facture + avoirs -> état final par article + net (format attendu par KbFacturationService::appliquer)
     */
    public function etatFinal($facture, array $avoirs)
    {
        $fac = $this->document('FAC', $facture);
        $docs = [$fac];
        foreach ($avoirs as $av) {
            $d = $this->document('FAC', $av);
            if ($d['client'] !== $fac['client']) {
                throw new KbFacturationException('Avoir ' . $av . ' d\'un autre client (' . $d['client'] . ') que la facture (' . $fac['client'] . ')');
            }
            if ($d['ttc'] > 0) {
                throw new KbFacturationException('Le document ' . $av . ' n\'est pas un avoir (montant positif)');
            }
            $docs[] = $d;
        }
        $final = [];
        $net = 0.0;
        foreach ($docs as $d) {
            $net += $d['ttc'];
            foreach ($d['lignes'] as $l) {
                if (!isset($final[$l['article']])) {
                    $final[$l['article']] = ['article' => $l['article'], 'qte' => 0.0, 'total_ttc' => 0.0];
                }
                $final[$l['article']]['qte'] += $l['qte'];
                $final[$l['article']]['total_ttc'] += $l['total_ttc'];
            }
        }
        foreach ($final as &$f) {
            $f['qte'] = round($f['qte'], 3);
            $f['total_ttc'] = round($f['total_ttc'], 2);
        }
        return ['client' => $fac['client'], 'net_ttc' => round($net, 2), 'lignes' => array_values($final)];
    }

    /**
     * ÉCRITURE : transforme une commande client (BCC) en facture. Retourne le n° de facture.
     */
    public function facturerCommande($bcc, $modeReglement = 'CB')
    {
        $this->numeroValide($bcc);
        $inner = '<d:facturerCommandeDemande version="1.1" commandeSource="' . $bcc . '" modeReglement="' . htmlspecialchars($modeReglement, ENT_QUOTES) . '"/>';
        $xml = $this->appel('document', 'facturerCommande', $inner, 60);
        return $this->numeroRetour($xml, 'facturerCommande ' . $bcc);
    }

    /**
     * ÉCRITURE : dépose une facture négative (avoir) pour un client. $lignes = [[article, quantite, pu_ttc]].
     */
    public function deposerAvoir($client, array $lignes, $reference, $commentaire, $messageInterne, $modeReglement = 'CB')
    {
        if (!preg_match('/^[0-9A-Za-z_\-]{1,32}$/', (string) $client) || !$lignes) {
            throw new KbFacturationException('Avoir PDV : client ou lignes invalides');
        }
        $e = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES | ENT_XML1, 'UTF-8'); };
        $xmlL = '';
        $total = 0.0;
        $n = 0;
        foreach ($lignes as $l) {
            $q = (int) $l[1];
            $pu = round((float) $l[2], 2);
            if ($q === 0 || $pu < 0) {
                continue;
            }
            $n++;
            $total += $q * $pu;
            $xmlL .= '<ligne numeroLigne="' . $n . '" article="' . $e($l[0]) . '" quantite="' . $q . '" prixUnitaireBrut="' . number_format($pu, 2, '.', '')
                . '" remisePourcent="0" prixUnitaireNet="' . number_format($pu, 2, '.', '') . '"/>';
        }
        $total = round($total, 2);
        if ($n === 0 || $total >= 0) {
            throw new KbFacturationException('Avoir PDV : total non négatif (' . $total . ')');
        }
        $inner = '<d:deposerDemande version="1.1"><typeDocument code="FAC"/>'
            . '<entete client="' . $e($client) . '" modeSaisie="T" reference="' . $e(Tools::substr($reference, 0, 30)) . '"/>'
            . '<informations commentaire="' . $e(Tools::substr($commentaire, 0, 120)) . '" messageInterne="' . $e(Tools::substr($messageInterne, 0, 250)) . '"/>'
            . $xmlL . '<paiement modeReglement="' . $e($modeReglement) . '" montantReglement="' . number_format($total, 2, '.', '') . '"/></d:deposerDemande>';
        $xml = $this->appel('document', 'deposer', $inner, 60);
        return ['numero' => $this->numeroRetour($xml, 'deposer avoir'), 'total' => $total];
    }

    private function numeroValide($n)
    {
        if (!preg_match('/^[0-9A-Za-z\-]{3,32}$/', (string) $n)) {
            throw new KbFacturationException('Numéro PDV invalide : ' . $n);
        }
    }

    /** Lit le n° de document créé dans la réponse SOAP ; erreur PDV lisible sinon. */
    private function numeroRetour($xml, $quoi)
    {
        $sx = @simplexml_load_string($xml);
        if ($sx === false) {
            throw new KbFacturationException('Réponse G5 illisible (' . $quoi . ')');
        }
        $f = $sx->xpath('//*[local-name()="faultstring"]');
        if ($f) {
            throw new KbFacturationException('PDV a refusé ' . $quoi . ' : ' . (string) $f[0]);
        }
        foreach (['numeroFacture', 'numeroDocument', 'numero', 'document'] as $att) {
            $r = $sx->xpath('//@' . $att);
            if ($r && preg_match('/^\d+-\d+-\d+$/', trim((string) $r[0]))) {
                return trim((string) $r[0]);
            }
            $r = $sx->xpath('//*[local-name()="' . $att . '"]');
            if ($r && preg_match('/^\d+-\d+-\d+$/', trim((string) $r[0]))) {
                return trim((string) $r[0]);
            }
        }
        if (preg_match('/(?<![\d\-])(\d{1,3}-\d{1,3}-\d{1,9})(?![\d\-])/', strip_tags(preg_replace('/<\?xml[^>]*>/', '', $xml)), $m)) {
            return $m[1];
        }
        throw new KbFacturationException('PDV : n° de document introuvable dans la réponse (' . $quoi . ') — VÉRIFIER DANS PDV avant de relancer');
    }

    private function appel($service, $action, $inner, $timeout = 20)
    {
        $ns = 'ns://connect.pdv.progmag.com/' . $service;
        $body = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:d="' . $ns . '"><soapenv:Header/><soapenv:Body>'
            . $inner . '</soapenv:Body></soapenv:Envelope>';
        $ch = curl_init($this->base . $service);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => ['Content-Type: text/xml; charset=utf-8', 'SOAPAction: "ns://connect.pdv.progmag.com/' . $action . '"'],
            CURLOPT_POSTFIELDS => $body,
        ]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === false || $raw === '') {
            throw new KbFacturationException('Serveur G5 injoignable depuis PrestaShop : ' . $err);
        }
        return $raw;
    }
}
