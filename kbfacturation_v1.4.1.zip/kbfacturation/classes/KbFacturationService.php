<?php
/**
 * Applique la facturation PDV (facture + avoirs) sur une commande PrestaShop.
 * Tout est calculé et vérifié AVANT la moindre écriture ; écriture en transaction.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbFacturationException extends Exception
{
}

class KbFacturationService
{
    const EPS = 0.011; // tolérance d'arrondi en euros

    /** @var Module */
    private $module;

    public function __construct(Module $module)
    {
        $this->module = $module;
    }

    /**
     * $p = [
     *   reference, id_order?, dry_run?,
     *   pdv => [commande, facture, avoirs[]],
     *   net_ttc,
     *   lignes => [[article, qte, total_ttc], ...]   // état FINAL par article (facture - avoirs), hors PORT
     * ]
     */
    public function appliquer(array $p)
    {
        if (method_exists($this->module, 'assurerSchema')) {
            $this->module->assurerSchema(); // colonne `detail` présente avant toute écriture
        }
        $order = $this->loadOrder($p);
        $pdv = (array) ($p['pdv'] ?? []);
        $fac = trim((string) ($pdv['facture'] ?? ''));
        $cmd = trim((string) ($pdv['commande'] ?? ''));
        $avoirs = array_values(array_filter(array_map('trim', (array) ($pdv['avoirs'] ?? []))));
        if (!preg_match('/^[0-9A-Za-z\-]{3,32}$/', $fac) || !preg_match('/^[0-9A-Za-z\-]{3,32}$/', $cmd)) {
            throw new KbFacturationException('Numéros PDV (commande/facture) manquants ou invalides');
        }
        if (!isset($p['net_ttc']) || !is_numeric($p['net_ttc']) || (float) $p['net_ttc'] < 0) {
            throw new KbFacturationException('net_ttc manquant ou invalide');
        }
        $netAttendu = round((float) $p['net_ttc'], 2);
        $dry = !empty($p['dry_run']);

        // Idempotence
        $deja = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_order` WHERE id_order=' . (int) $order->id);
        if ($deja) {
            if ($deja['pdv_facture'] === $fac && abs((float) $deja['net_ttc'] - $netAttendu) < self::EPS) {
                return ['statut' => 'deja_applique', 'id_order' => (int) $order->id, 'net_ttc' => (float) $deja['net_ttc'],
                        'captured' => (int) $deja['captured']];
            }
            throw new KbFacturationException('Commande déjà ajustée avec la facture ' . $deja['pdv_facture'] . ' (' . $deja['net_ttc'] . ' €) : refus');
        }

        $state = (int) $order->getCurrentState();
        $interdits = [(int) Configuration::get('PS_OS_CANCELED'), (int) Configuration::get('PS_OS_REFUND'), (int) Configuration::get('PS_OS_PAYMENT')];
        if (in_array($state, $interdits, true)) {
            throw new KbFacturationException('Statut actuel incompatible (id_order_state=' . $state . ')');
        }

        // Lignes finales demandées, indexées par article (EAN = référence produit)
        $cible = [];
        foreach ((array) ($p['lignes'] ?? []) as $l) {
            $art = trim((string) ($l['article'] ?? ''));
            if ($art === '' || strtoupper($art) === 'PORT') {
                continue;
            }
            if (!isset($l['qte'], $l['total_ttc']) || !is_numeric($l['qte']) || !is_numeric($l['total_ttc'])) {
                throw new KbFacturationException('Ligne invalide pour l\'article ' . $art);
            }
            if (isset($cible[$art])) { // même article sur plusieurs lignes PDV : on cumule
                $cible[$art]['qte'] += (float) $l['qte'];
                $cible[$art]['total_ttc'] += (float) $l['total_ttc'];
            } else {
                $cible[$art] = ['qte' => (float) $l['qte'], 'total_ttc' => (float) $l['total_ttc'], 'vu' => false];
            }
        }
        if (!$cible) {
            throw new KbFacturationException('Aucune ligne article reçue');
        }

        // Plan de modification
        $plan = [];
        $sumIncl = 0.0;
        $sumExcl = 0.0;
        $journal = [];
        $lignesDetail = []; // récap ligne à ligne (affiché barré pour les ruptures, côté admin et client)
        $details = OrderDetail::getList((int) $order->id);
        foreach ($details as $d) {
            $od = new OrderDetail((int) $d['id_order_detail']);
            $key = $this->cle($od, $cible);
            if ($key === null) {
                throw new KbFacturationException('Ligne PrestaShop sans équivalent PDV : ' . $od->product_name . ' (' . $od->product_reference . ')');
            }
            $cible[$key]['vu'] = true;
            $q = $cible[$key]['qte'];
            $tIncl = round($cible[$key]['total_ttc'], 6);
            if ($q < 0 || $tIncl < -self::EPS) {
                throw new KbFacturationException('Quantité/montant négatif pour ' . $od->product_name);
            }
            $taux = $this->tauxTva($od);
            $tExcl = $q > 0 ? round($tIncl / (1 + $taux), 6) : 0.0;
            $oldQ = (int) $od->product_quantity;
            $oldIncl = (float) $od->total_price_tax_incl;
            if ($q > 0 && abs($q - round($q)) > 0.0001) {
                throw new KbFacturationException('Quantité non entière pour ' . $od->product_name . ' : ' . $q);
            }
            $q = (int) round($q);
            $ld = ['nom' => (string) $od->product_name, 'ref' => (string) $od->product_reference,
                'qte_init' => $oldQ, 'ttc_init' => round($oldIncl, 2), 'qte' => $q, 'ttc' => round($q > 0 ? $tIncl : 0, 2)];
            if ($q === 0) {
                $ld['etat'] = 'retire';
                $lignesDetail[] = $ld;
                $plan[] = ['op' => 'supprimer', 'od' => $od];
                $journal[] = 'Rupture : ' . $od->product_name . ' x' . $oldQ . ' (' . $this->eur($oldIncl) . ') retiré';
            } elseif ($q !== $oldQ || abs($tIncl - $oldIncl) > self::EPS) {
                $ld['etat'] = $q !== $oldQ ? 'quantite' : 'remise';
                $lignesDetail[] = $ld;
                $plan[] = ['op' => 'modifier', 'od' => $od, 'q' => $q, 'incl' => $tIncl, 'excl' => $tExcl, 'taux' => $taux];
                $journal[] = $od->product_name . ' : x' . $oldQ . ' ' . $this->eur($oldIncl) . ' -> x' . $q . ' ' . $this->eur($tIncl);
                $sumIncl += $tIncl;
                $sumExcl += $tExcl;
            } else {
                $ld['etat'] = 'ok';
                $ld['ttc'] = round($oldIncl, 2);
                $lignesDetail[] = $ld;
                $sumIncl += $oldIncl;
                $sumExcl += (float) $od->total_price_tax_excl;
            }
        }
        foreach ($cible as $art => $c) {
            if (!$c['vu'] && ($c['qte'] != 0 || abs($c['total_ttc']) > self::EPS)) {
                throw new KbFacturationException('Article PDV absent de la commande PrestaShop : ' . $art . ' (substitution non gérée en v1)');
            }
        }

        $shipIncl = (float) $order->total_shipping_tax_incl;
        $shipExcl = (float) $order->total_shipping_tax_excl;
        $wrapIncl = (float) $order->total_wrapping_tax_incl;
        $wrapExcl = (float) $order->total_wrapping_tax_excl;
        $discIncl = (float) $order->total_discounts_tax_incl;
        $discExcl = (float) $order->total_discounts_tax_excl;
        $totalIncl = round($sumIncl + $shipIncl + $wrapIncl - $discIncl, 6);
        $totalExcl = round($sumExcl + $shipExcl + $wrapExcl - $discExcl, 6);

        if (abs(round($totalIncl, 2) - $netAttendu) > self::EPS) {
            throw new KbFacturationException('Écart de contrôle : total PrestaShop recalculé ' . $this->eur($totalIncl)
                . ' ≠ net PDV ' . $this->eur($netAttendu) . ' (port ' . $this->eur($shipIncl) . ', réductions ' . $this->eur($discIncl) . ')');
        }

        $initial = (float) $order->total_paid_tax_incl;
        $resume = [
            'statut' => $dry ? 'simulation' : 'applique',
            'id_order' => (int) $order->id,
            'reference' => $order->reference,
            'total_initial_ttc' => round($initial, 2),
            'net_ttc' => round($totalIncl, 2),
            'modifications' => $journal ?: ['Aucun écart : commande conforme'],
            'lignes_detail' => $lignesDetail,
        ];
        if ($dry) {
            return $resume;
        }

        // Écriture
        $db = Db::getInstance();
        $db->execute('START TRANSACTION');
        try {
            foreach ($plan as $a) {
                /** @var OrderDetail $od */
                $od = $a['od'];
                if ($a['op'] === 'supprimer') {
                    $db->delete('order_detail_tax', 'id_order_detail=' . (int) $od->id);
                    if (!$od->delete()) {
                        throw new KbFacturationException('Suppression impossible : ' . $od->product_name);
                    }
                    continue;
                }
                $q = $a['q'];
                $od->product_quantity = $q;
                $od->total_price_tax_incl = $a['incl'];
                $od->total_price_tax_excl = $a['excl'];
                $od->unit_price_tax_incl = round($a['incl'] / $q, 6);
                $od->unit_price_tax_excl = round($a['excl'] / $q, 6);
                if (!$od->update()) {
                    throw new KbFacturationException('Mise à jour impossible : ' . $od->product_name);
                }
                $db->update('order_detail_tax', [
                    'unit_amount' => round(($a['incl'] - $a['excl']) / $q, 6),
                    'total_amount' => round($a['incl'] - $a['excl'], 6),
                ], 'id_order_detail=' . (int) $od->id);
            }

            $order->total_products = round($sumExcl, 6);
            $order->total_products_wt = round($sumIncl, 6);
            $order->total_paid_tax_incl = $totalIncl;
            $order->total_paid_tax_excl = $totalExcl;
            $order->total_paid = $totalIncl;
            $note = '[' . date('d/m/Y H:i') . '] Facturation PDV : commande ' . $cmd . ', facture ' . $fac
                . ($avoirs ? ', avoir(s) ' . implode(', ', $avoirs) : '') . '. Montant initial ' . $this->eur($initial)
                . ', montant réel ' . $this->eur($totalIncl) . '.' . ($journal ? ' ' . implode(' ; ', $journal) . '.' : '');
            if (property_exists($order, 'note')) {
                $order->note = trim((string) $order->note . "\n" . $note);
            }
            if (!$order->update()) {
                throw new KbFacturationException('Mise à jour de la commande impossible');
            }

            // Facture PrestaShop éventuelle : alignée sur les nouveaux totaux
            foreach ($order->getInvoicesCollection() as $inv) {
                $inv->total_products = round($sumExcl, 6);
                $inv->total_products_wt = round($sumIncl, 6);
                $inv->total_paid_tax_incl = $totalIncl;
                $inv->total_paid_tax_excl = $totalExcl;
                $inv->update();
            }

            $db->insert('kbfact_order', [
                'id_order' => (int) $order->id,
                'pdv_commande' => pSQL($cmd),
                'pdv_facture' => pSQL($fac),
                'pdv_avoirs' => pSQL(implode(', ', $avoirs)),
                'total_initial_ttc' => $initial,
                'net_ttc' => $totalIncl,
                'captured' => 0,
                'detail' => pSQL(json_encode($lignesDetail, JSON_UNESCAPED_UNICODE)),
                'date_applied' => date('Y-m-d H:i:s'),
            ]);
            $db->execute('COMMIT');
        } catch (Exception $e) {
            $db->execute('ROLLBACK');
            throw $e;
        }

        // Hors transaction : message privé + statut (non bloquants)
        $this->messagePrive($order, $note);
        $idState = (int) Configuration::get(Kbfacturation::CFG_STATE_FACTURE);
        if ($idState && (int) $order->getCurrentState() !== $idState) {
            $h = new OrderHistory();
            $h->id_order = (int) $order->id;
            $h->id_employee = 0;
            $h->changeIdOrderState($idState, $order, true);
            $h->add();
        }
        return $resume;
    }

    public function loadOrder(array $p)
    {
        $ref = trim((string) ($p['reference'] ?? ''));
        if (!preg_match('/^[A-Z0-9]{5,16}$/', $ref)) {
            throw new KbFacturationException('Référence de commande invalide');
        }
        $col = Order::getByReference($ref);
        if (!$col || !count($col)) {
            throw new KbFacturationException('Commande introuvable : ' . $ref);
        }
        if (count($col) > 1) {
            throw new KbFacturationException('Référence partagée par plusieurs commandes (multi-transporteur) : non géré');
        }
        $order = $col->getFirst();
        if (!empty($p['id_order']) && (int) $p['id_order'] !== (int) $order->id) {
            throw new KbFacturationException('id_order ' . (int) $p['id_order'] . ' ne correspond pas à ' . $ref);
        }
        return $order;
    }

    private function cle(OrderDetail $od, array $cible)
    {
        foreach ([(string) $od->product_reference, (string) $od->product_ean13, (string) $od->product_upc] as $k) {
            $k = trim($k);
            if ($k !== '' && isset($cible[$k])) {
                return $k;
            }
        }
        return null;
    }

    private function tauxTva(OrderDetail $od)
    {
        $r = (float) Db::getInstance()->getValue(
            'SELECT t.rate FROM `' . _DB_PREFIX_ . 'order_detail_tax` odt JOIN `' . _DB_PREFIX_ . 'tax` t ON t.id_tax=odt.id_tax WHERE odt.id_order_detail=' . (int) $od->id
        );
        if ($r > 0) {
            return $r / 100;
        }
        if ((float) $od->unit_price_tax_excl > 0) {
            return max(0, round((float) $od->unit_price_tax_incl / (float) $od->unit_price_tax_excl - 1, 4));
        }
        return (float) $od->tax_rate / 100;
    }

    public function messagePrive(Order $order, $txt)
    {
        try {
            $m = new Message();
            $m->id_order = (int) $order->id;
            $m->id_cart = (int) $order->id_cart;
            $m->id_customer = 0;
            $m->id_employee = 0;
            $m->private = 1;
            $m->message = Tools::substr(strip_tags($txt), 0, 1600);
            $m->add();
        } catch (Exception $e) {
            // non bloquant
        }
    }

    public function eur($v)
    {
        return number_format((float) $v, 2, ',', ' ') . ' €';
    }
}
