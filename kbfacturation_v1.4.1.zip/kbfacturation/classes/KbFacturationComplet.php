<?php
/**
 * Facturation COMPLÈTE d'une commande web, déclenchée par l'appli Kelbongoo à la clôture de la distribution :
 *   1. PDV : BCC (commande) → FACTURE        (API G5 document.facturerCommande)
 *   2. PDV : AVOIR des ruptures / remises     (API G5 document.deposer FAC négative)
 *   3. Site : commande au montant réel        (KbFacturationService::appliquer)
 *   4. PayZen : débit du montant réel         (si la capture est activée)
 *
 * Reprise sûre : chaque étape est mémorisée dans kbfact_pdv AVANT/APRÈS l'appel PDV.
 * Un appel PDV dont la réponse n'a pas été lue (étape « …_en_cours ») bloque la relance automatique :
 * il faut vérifier dans PDV (jamais de double facture).
 *
 * $ecarts = [[ean, produit, manque(int), remise_pct(0-100), remise_qte(int)]]
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbFacturationComplet
{
    private $module;
    private $svc;
    private $g5;

    public function __construct(Module $module)
    {
        $this->module = $module;
        $this->svc = new KbFacturationService($module);
        $this->g5 = new KbFacturationG5();
    }

    public static function installTable()
    {
        return Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'kbfact_pdv` (
            `id_order` INT UNSIGNED NOT NULL PRIMARY KEY,
            `bcc` VARCHAR(32) NOT NULL,
            `facture` VARCHAR(32) NULL,
            `avoir` VARCHAR(32) NULL,
            `etape` VARCHAR(32) NOT NULL DEFAULT \'\',
            `ecarts` MEDIUMTEXT NULL,
            `date_upd` DATETIME NOT NULL
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4');
    }

    public function facturer(array $p)
    {
        self::installTable();
        $order = $this->svc->loadOrder($p);
        $id = (int) $order->id;
        $dry = !empty($p['dry_run']);
        $db = Db::getInstance();

        $deja = $db->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_order` WHERE id_order=' . $id);
        if ($deja) {
            $out = ['statut' => 'deja_facture', 'reference' => $order->reference, 'id_order' => $id, 'pdv_facture' => $deja['pdv_facture'],
                'pdv_avoirs' => $deja['pdv_avoirs'], 'net_ttc' => (float) $deja['net_ttc'], 'captured' => (int) $deja['captured']];
            return $dry ? $out : $this->capturerSiActif($order, $out);
        }

        $prefixe = (string) (Configuration::get(Kbfacturation::CFG_BCC_PREFIX) ?: '98-98-');
        $bcc = trim((string) ($p['bcc'] ?? '')) ?: $prefixe . $id;
        $row = $db->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_pdv` WHERE id_order=' . $id) ?: null;
        $ecarts = $this->normaliserEcarts((array) ($p['ecarts'] ?? []));

        // Document de base pour le plan : la facture si elle existe déjà, sinon la commande PDV
        $base = ($row && $row['facture']) ? $this->g5->document('FAC', $row['facture']) : $this->g5->document('BCC', $bcc);
        $this->controlerCorrespondance($order, $base, $bcc);
        $lignesAvoir = $this->lignesAvoir($base, $ecarts);
        $totalAvoir = 0.0;
        foreach ($lignesAvoir as $l) {
            $totalAvoir += $l[1] * $l[2];
        }
        $plan = [
            'reference' => $order->reference, 'id_order' => $id, 'bcc' => $bcc, 'client_pdv' => $base['client'],
            'montant_commande' => round($base['ttc'], 2), 'avoir_ttc' => round($totalAvoir, 2),
            'net_prevu' => round($base['ttc'] + $totalAvoir, 2),
            'lignes_avoir' => array_map(function ($l) { return ['article' => $l[0], 'qte' => $l[1], 'pu' => $l[2], 'libelle' => $l[3]]; }, $lignesAvoir),
        ];
        if ($dry) {
            return ['statut' => 'simulation'] + $plan;
        }

        // 1. Facture
        if (!$row) {
            $db->insert('kbfact_pdv', ['id_order' => $id, 'bcc' => pSQL($bcc), 'etape' => 'nouveau', 'ecarts' => pSQL(json_encode($ecarts, JSON_UNESCAPED_UNICODE)), 'date_upd' => date('Y-m-d H:i:s')]);
            $row = ['facture' => null, 'avoir' => null, 'etape' => 'nouveau'];
        }
        if (!$row['facture']) {
            if ($row['etape'] === 'facture_en_cours') {
                throw new KbFacturationException('Facturation PDV de ' . $bcc . ' interrompue : vérifier dans PDV si la facture existe, puis la saisir dans le secours manuel');
            }
            $this->etape($id, ['etape' => 'facture_en_cours']);
            $facture = $this->g5->facturerCommande($bcc, 'CB');
            $this->etape($id, ['etape' => 'facture_ok', 'facture' => $facture]);
            $row['facture'] = $facture;
            $row['etape'] = 'facture_ok';
            $base = $this->g5->document('FAC', $facture);
            $lignesAvoir = $this->lignesAvoir($base, $ecarts); // recalcul sur les PU de la facture réelle
        }

        // 2. Avoir (seulement s'il y a des écarts)
        $avoirs = [];
        if ($row['avoir']) {
            $avoirs[] = $row['avoir'];
        } elseif ($lignesAvoir) {
            if ($row['etape'] === 'avoir_en_cours') {
                throw new KbFacturationException('Avoir PDV de la facture ' . $row['facture'] . ' interrompu : vérifier dans PDV, puis le saisir dans le secours manuel');
            }
            $this->etape($id, ['etape' => 'avoir_en_cours']);
            $av = $this->g5->deposerAvoir($base['client'], $lignesAvoir, 'AV ' . $row['facture'] . ' WEB',
                'Avoir ruptures/remises - fac ' . $row['facture'],
                'Avoir automatique KBG. Facture ' . $row['facture'] . ' / commande ' . $bcc . ' / web ' . $order->reference);
            $this->etape($id, ['etape' => 'avoir_ok', 'avoir' => $av['numero']]);
            $avoirs[] = $av['numero'];
        }

        // 3. Site au montant réel (relecture PDV = source de vérité)
        $etat = $this->g5->etatFinal($row['facture'], $avoirs);
        $r = $this->svc->appliquer(['reference' => $order->reference, 'pdv' => ['commande' => $bcc, 'facture' => $row['facture'], 'avoirs' => $avoirs],
            'net_ttc' => $etat['net_ttc'], 'lignes' => $etat['lignes']]);
        $this->etape($id, ['etape' => 'site_ok']);
        $r['pdv_facture'] = $row['facture'];
        $r['pdv_avoirs'] = implode(', ', $avoirs);
        $r['pdv_commande'] = $bcc;

        // 4. PayZen
        return $this->capturerSiActif($order, $r);
    }

    private function capturerSiActif(Order $order, array $r)
    {
        $pz = new KbFacturationPayzen();
        if (!$pz->actif()) {
            $r['payzen'] = 'capture désactivée (configuration du module)';
            return $r;
        }
        try {
            $r['payzen'] = $pz->capturer(new Order((int) $order->id), $this->svc, null);
        } catch (KbFacturationException $e) {
            $r['payzen'] = 'ERREUR : ' . $e->getMessage();
            $r['payzen_erreur'] = true;
        }
        return $r;
    }

    private function etape($id, array $f)
    {
        $f['date_upd'] = date('Y-m-d H:i:s');
        Db::getInstance()->update('kbfact_pdv', array_map('pSQL', $f), 'id_order=' . (int) $id);
    }

    private function normaliserEcarts(array $in)
    {
        $out = [];
        foreach ($in as $e) {
            $manque = max(0, (int) ($e['manque'] ?? 0));
            $pct = max(0, min(100, (float) ($e['remise_pct'] ?? 0)));
            $rq = max(0, (int) ($e['remise_qte'] ?? 0));
            if ($pct >= 100) { // remise 100 % = retrait
                $manque += $rq;
                $pct = 0;
                $rq = 0;
            }
            if ($manque === 0 && ($pct <= 0 || $rq === 0)) {
                continue;
            }
            $out[] = ['ean' => preg_replace('/[^0-9A-Za-z]/', '', (string) ($e['ean'] ?? '')), 'produit' => Tools::substr((string) ($e['produit'] ?? ''), 0, 200),
                'manque' => $manque, 'remise_pct' => $pct, 'remise_qte' => $rq];
        }
        return $out;
    }

    private function nrm($s)
    {
        $s = Tools::strtolower(Tools::replaceAccentedChars((string) $s));
        return trim(preg_replace('/[^a-z0-9]+/', ' ', str_replace('[test]', '', $s)));
    }

    /** Lignes de l'avoir, prix unitaires lus dans le document PDV (jamais ceux de l'appli). */
    private function lignesAvoir(array $doc, array $ecarts)
    {
        $parArt = [];
        foreach ($doc['lignes'] as $l) {
            if ($l['qte'] <= 0) {
                continue;
            }
            $a = $l['article'];
            if (!isset($parArt[$a])) {
                $parArt[$a] = ['qte' => 0, 'ttc' => 0, 'designation' => $l['designation']];
            }
            $parArt[$a]['qte'] += $l['qte'];
            $parArt[$a]['ttc'] += $l['total_ttc'];
        }
        $out = [];
        foreach ($ecarts as $e) {
            $art = ($e['ean'] !== '' && isset($parArt[$e['ean']])) ? $e['ean'] : null;
            if ($art === null) {
                $n = $this->nrm($e['produit']);
                foreach ($parArt as $a => $x) {
                    if ($n !== '' && $this->nrm($x['designation']) === $n) {
                        $art = $a;
                        break;
                    }
                }
            }
            if ($art === null) {
                throw new KbFacturationException('Article introuvable dans le document PDV : ' . $e['produit'] . ' (EAN ' . ($e['ean'] ?: '?') . ')');
            }
            $x = $parArt[$art];
            $art = (string) $art;
            $pu = round($x['ttc'] / max(1, $x['qte']), 2);
            $manque = min($e['manque'], (int) $x['qte']);
            if ($manque > 0) {
                $out[] = [$art, -$manque, $pu, 'rupture ' . $x['designation']];
            }
            $rq = min($e['remise_qte'], (int) $x['qte'] - $manque);
            if ($rq > 0 && $e['remise_pct'] > 0) {
                $puRemise = round($pu * (1 - $e['remise_pct'] / 100), 2);
                $out[] = [$art, -$rq, $pu, 'remise ' . $e['remise_pct'] . '% ' . $x['designation']];
                $out[] = [$art, $rq, $puRemise, 'remise ' . $e['remise_pct'] . '% ' . $x['designation']];
            }
        }
        return $out;
    }

    /** Garde-fou : le document PDV correspond bien à cette commande web (montant de la commande). */
    private function controlerCorrespondance(Order $order, array $doc, $bcc)
    {
        $total = round((float) $order->total_paid_tax_incl, 2);
        if (abs(round($doc['ttc'], 2) - $total) > 0.011) {
            throw new KbFacturationException('Le document PDV ' . $bcc . ' (' . $this->svc->eur($doc['ttc']) . ') ne correspond pas au montant de la commande '
                . $order->reference . ' (' . $this->svc->eur($total) . ') : indiquer le n° de commande PDV');
        }
    }
}
