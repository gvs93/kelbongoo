<?php
/**
 * Capture PayZen (API REST V4) au montant net facturé par PDV.
 * Désactivée par défaut (configuration du module). Jamais au-dessus du montant autorisé.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class KbFacturationPayzen
{
    private $shop;
    private $key;
    private $base;

    public function __construct()
    {
        $this->shop = (string) Configuration::get(Kbfacturation::CFG_PZ_SHOP);
        $this->key = (string) Configuration::get(Kbfacturation::CFG_PZ_KEY);
        $this->base = rtrim((string) Configuration::get(Kbfacturation::CFG_PZ_URL), '/') . '/';
    }

    public function actif()
    {
        return (int) Configuration::get(Kbfacturation::CFG_CAPTURE_ON) === 1 && $this->shop !== '' && $this->key !== '';
    }

    /**
     * @return array résultat lisible
     */
    public function capturer(Order $order, KbFacturationService $svc, $uuidFourni = null)
    {
        $row = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'kbfact_order` WHERE id_order=' . (int) $order->id);
        if (!$row) {
            throw new KbFacturationException('Commande non encore ajustée par la facturation PDV : capture refusée');
        }
        if ((int) $row['captured'] === 1) {
            return ['statut' => 'deja_capture', 'montant' => (float) $row['captured_amount']];
        }
        if (!$this->actif()) {
            throw new KbFacturationException('Capture PayZen désactivée dans la configuration du module');
        }
        $net = round((float) $row['net_ttc'], 2);
        $cents = (int) round($net * 100);

        $tx = $this->trouverTransaction($order, $uuidFourni);
        $autorise = (int) $tx['amount'];
        if ($cents > $autorise) {
            throw new KbFacturationException('Montant net ' . $svc->eur($net) . ' supérieur à l\'autorisation ' . $svc->eur($autorise / 100) . ' : aucun débit');
        }

        if ($cents === 0) {
            $r = $this->appel('Transaction/CancelOrRefund', ['uuid' => $tx['uuid'], 'resolutionMode' => 'CANCELLATION_ONLY']);
        } else {
            $r = $this->appel('Transaction/Update', [
                'uuid' => $tx['uuid'],
                'cardUpdate' => ['amount' => $cents, 'currency' => 'EUR', 'manualValidation' => 'NO'],
            ]);
        }
        if (($r['status'] ?? '') !== 'SUCCESS') {
            $err = $r['answer']['errorMessage'] ?? ($r['answer']['detailedErrorMessage'] ?? json_encode($r));
            throw new KbFacturationException('PayZen a refusé : ' . $err);
        }

        Db::getInstance()->update('kbfact_order', [
            'captured' => 1,
            'captured_amount' => $net,
            'date_captured' => date('Y-m-d H:i:s'),
        ], 'id_order=' . (int) $order->id);

        // Paiement PrestaShop aligné sur le montant réellement débité
        foreach ($order->getOrderPaymentCollection() as $pay) {
            $pay->amount = $net;
            $pay->update();
            break;
        }
        $h = new OrderHistory();
        $h->id_order = (int) $order->id;
        $h->id_employee = 0;
        $h->changeIdOrderState((int) Configuration::get('PS_OS_PAYMENT'), $order, true);
        $h->add();
        $svc->messagePrive($order, '[' . date('d/m/Y H:i') . '] PayZen : ' . ($cents ? 'capture de ' . $svc->eur($net) : 'autorisation annulée (rien à payer)')
            . ' sur la transaction ' . $tx['uuid'] . ' (autorisé ' . $svc->eur($autorise / 100) . ').');

        return ['statut' => $cents ? 'capture' : 'annule', 'montant' => $net, 'autorise' => $autorise / 100];
    }

    private function trouverTransaction(Order $order, $uuidFourni)
    {
        if ($uuidFourni && preg_match('/^[0-9a-f]{32}$/', $uuidFourni)) {
            $r = $this->appel('Transaction/Get', ['uuid' => $uuidFourni]);
            if (($r['status'] ?? '') === 'SUCCESS') {
                return $this->verifier($r['answer']);
            }
        }
        // UUID présent dans les messages de la commande (module PayZen / kbprogmag)
        $msgs = Db::getInstance()->executeS('SELECT message FROM `' . _DB_PREFIX_ . 'message` WHERE id_order=' . (int) $order->id) ?: [];
        foreach ($msgs as $m) {
            if (preg_match_all('/\b([0-9a-f]{32})\b/', $m['message'], $mm)) {
                foreach ($mm[1] as $u) {
                    $r = $this->appel('Transaction/Get', ['uuid' => $u]);
                    if (($r['status'] ?? '') === 'SUCCESS') {
                        return $this->verifier($r['answer']);
                    }
                }
            }
        }
        // Recherche par numéro de commande marchand (panier puis référence)
        foreach ([(string) $order->id_cart, (string) $order->reference, (string) $order->id] as $oid) {
            $r = $this->appel('Order/Get', ['orderId' => $oid]);
            if (($r['status'] ?? '') === 'SUCCESS' && !empty($r['answer']['transactions'])) {
                foreach ($r['answer']['transactions'] as $t) {
                    if (in_array($t['detailedStatus'] ?? '', ['AUTHORISED_TO_VALIDATE', 'WAITING_AUTHORISATION_TO_VALIDATE', 'AUTHORISED'], true)) {
                        return $this->verifier($t);
                    }
                }
            }
        }
        throw new KbFacturationException('Transaction PayZen introuvable pour la commande ' . $order->reference);
    }

    private function verifier(array $t)
    {
        $st = $t['detailedStatus'] ?? '';
        if (!in_array($st, ['AUTHORISED_TO_VALIDATE', 'WAITING_AUTHORISATION_TO_VALIDATE', 'AUTHORISED'], true)) {
            throw new KbFacturationException('Transaction PayZen ' . ($t['uuid'] ?? '?') . ' dans un état non capturable : ' . $st);
        }
        return ['uuid' => $t['uuid'], 'amount' => (int) $t['amount'], 'status' => $st];
    }

    private function appel($route, array $body)
    {
        $ch = curl_init($this->base . $route);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Basic ' . base64_encode($this->shop . ':' . $this->key)],
            CURLOPT_POSTFIELDS => json_encode($body),
        ]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === false) {
            throw new KbFacturationException('PayZen injoignable : ' . $err);
        }
        $j = json_decode($raw, true);
        if (!is_array($j)) {
            throw new KbFacturationException('Réponse PayZen illisible');
        }
        return $j;
    }
}
