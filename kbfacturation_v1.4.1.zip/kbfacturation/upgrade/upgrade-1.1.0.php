<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_0($module)
{
    if (!Configuration::get('KBFACT_G5_URL')) {
        Configuration::updateValue('KBFACT_G5_URL', 'http://172.21.3.94:8080/axis2/services/');
    }
    return true;
}
