<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * 1.3.0 : colonne `detail` (récap ligne à ligne) + hooks admin / compte client.
 * Rattrapage des commandes déjà ajustées : lignes conservées = lignes actuelles de la commande,
 * lignes retirées = relues dans le journal (« Rupture : NOM xQ (P €) retiré »).
 */
if (!function_exists('upgrade_module_1_3_0')) {
function upgrade_module_1_3_0($module)
{
    $db = Db::getInstance();
    $p = _DB_PREFIX_;
    $cols = $db->executeS("SHOW COLUMNS FROM `{$p}kbfact_order` LIKE 'detail'");
    if (!$cols && !$db->execute("ALTER TABLE `{$p}kbfact_order` ADD `detail` MEDIUMTEXT NULL AFTER `captured_amount`")) {
        return false;
    }
    $module->registerHook('displayAdminOrderMainBottom');
    $module->registerHook('displayOrderDetail');
    Configuration::updateValue('KBFACT_SCHEMA', 3);

    foreach ($db->executeS("SELECT id_order FROM `{$p}kbfact_order` WHERE detail IS NULL OR detail=''") ?: [] as $row) {
        $id = (int) $row['id_order'];
        $lignes = [];
        $log = $db->getValue("SELECT message FROM `{$p}kbfact_log` WHERE id_order={$id} AND ok=1 AND action IN ('manuel','appliquer','appliquer_pdv') ORDER BY id_log DESC");
        $msg = preg_replace('/ \[[^\]]+@[^\]]+\]$/', '', (string) $log);
        $res = json_decode($msg, true);
        foreach ((array) ($res['modifications'] ?? []) as $m) {
            if (preg_match('/^Rupture : (.+) x(\d+) \(([\d\s ,.]+) €\) retiré$/u', (string) $m, $x)) {
                $lignes[] = ['nom' => $x[1], 'ref' => '', 'qte_init' => (int) $x[2],
                    'ttc_init' => (float) str_replace([' ', ' ', ','], ['', '', '.'], $x[3]), 'qte' => 0, 'ttc' => 0, 'etat' => 'retire'];
            }
        }
        foreach (OrderDetail::getList($id) as $d) {
            $lignes[] = ['nom' => $d['product_name'], 'ref' => $d['product_reference'], 'qte_init' => (int) $d['product_quantity'],
                'ttc_init' => round((float) $d['total_price_tax_incl'], 2), 'qte' => (int) $d['product_quantity'],
                'ttc' => round((float) $d['total_price_tax_incl'], 2), 'etat' => 'ok'];
        }
        $db->update('kbfact_order', ['detail' => pSQL(json_encode($lignes, JSON_UNESCAPED_UNICODE))], 'id_order=' . $id);
    }
    return true;
}
}
