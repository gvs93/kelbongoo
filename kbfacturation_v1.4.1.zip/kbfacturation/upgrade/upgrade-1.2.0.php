<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_0($module)
{
    if (!Configuration::get('KBFACT_LOG_URL')) {
        Configuration::updateValue('KBFACT_LOG_URL', 'https://europe-west1-distribkbg.cloudfunctions.net/kbgFactuLog');
    }
    return true;
}
